# ORBE · du code-barres à la molécule

Application mobile (Android / web) :

- **Scanner** un code-barres (ou chercher un produit par nom) et lire sa fiche en clair : verdict, notes Nutri-Score / NOVA / Éco-Score expliquées, ingrédients, nutrition, additifs, traçabilité, prix.
- **Molécules en 3D** : chaque ingrédient identifié renvoie vers sa molécule, que l'on fait tourner au doigt (billes et bâtons / volume, hydrogènes, noms des atomes).
- **Tableau périodique interactif** : 118 éléments, recherche, filtres par famille, filtre « Dans l'alimentation », fiche détaillée avec électrons animés, molécules associées, et un quiz.
- **Favoris, historique, mini-glossaire** pour les débutants.

Les données produits viennent d'[Open Food Facts](https://world.openfoodfacts.org) (licence ODbL).
Aucun serveur n'est nécessaire : l'appli est 100 % côté client, donc compatible APK.

---

## Obtenir l'APK avec GitHub (sans rien installer)

1. Crée un dépôt GitHub (privé ou public) et envoie-y **tout le contenu de ce dossier**
   (y compris le dossier caché `.github`).
2. Va dans l'onglet **Actions** du dépôt. Le workflow **Build APK** se lance tout seul à chaque envoi sur `main`
   (tu peux aussi cliquer sur *Run workflow*).
3. Attends environ 6 à 10 minutes. Quand la coche verte apparaît, ouvre le run et télécharge
   **ORBE-apk** tout en bas (section *Artifacts*). Dézippe : tu obtiens `ORBE.apk`.
4. Envoie `ORBE.apk` sur ton téléphone et ouvre-le (autorise « installer des applis inconnues » si Android le demande).

> Astuce : crée un tag `v1.0.0` (`git tag v1.0.0 && git push --tags`) et l'APK sera aussi publié dans l'onglet **Releases**,
> avec un lien de téléchargement direct.

C'est un APK de *debug* : il s'installe directement. Pour le Google Play Store, il faudrait un APK/AAB signé (autre étape).

### Pourquoi le fichier s'appelle `build-apk.yml`
C'est le fichier du workflow GitHub Actions. Il doit rester à l'emplacement `.github/workflows/build-apk.yml`.

---

## Lancer en local (optionnel)

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # génère dist/
```

Pour créer le projet Android à la main (Android Studio + JDK 21 requis) :

```bash
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Pense à ajouter la permission caméra dans `android/app/src/main/AndroidManifest.xml` :
`<uses-permission android:name="android.permission.CAMERA" />` (le workflow GitHub le fait automatiquement).

## Structure

```
src/
  pages/        Accueil, Produit, Molécules, Tableau périodique, Profil
  components/   Visualiseur 3D (canvas), fiches élément/molécule, scanner, UI
  data/         118 éléments, glossaire
  lib/          molécules, catalogue de démo, Open Food Facts, favoris
.github/workflows/build-apk.yml   construction de l'APK
capacitor.config.ts               config Android (nom, identifiant)
assets/                           icône et écran de démarrage de l'APK
```

Pour changer le nom ou l'identifiant de l'appli : `capacitor.config.ts` (`appName`, `appId`).
