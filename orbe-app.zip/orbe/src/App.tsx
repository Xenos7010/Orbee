import { useEffect } from "react";
import { IconAtom, IconGrid, IconHome, IconUser } from "./components/icons";
import { HomePage } from "./pages/HomePage";
import { MePage } from "./pages/MePage";
import { MoleculesPage } from "./pages/MoleculesPage";
import { PeriodicPage } from "./pages/PeriodicPage";
import { ProductPage } from "./pages/ProductPage";
import { href, useRoute } from "./router";

const TABS = [
  { to: "/", key: "", label: "Accueil", Icon: IconHome },
  { to: "/molecules", key: "molecules", label: "Molécules", Icon: IconAtom },
  { to: "/tableau", key: "tableau", label: "Tableau", Icon: IconGrid },
  { to: "/moi", key: "moi", label: "Moi", Icon: IconUser },
];

export function App() {
  const path = useRoute();
  const [, root = "", arg = ""] = path.split("/").map((s) => decodeURIComponent(s));

  // Remonte en haut quand on change d'onglet (pas quand on ouvre une fiche dans le même onglet)
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [root]);

  let page;
  if (root === "produit") page = <ProductPage code={arg} />;
  else if (root === "molecules") page = <MoleculesPage id={arg || null} />;
  else if (root === "tableau") page = <PeriodicPage sym={arg || null} />;
  else if (root === "moi") page = <MePage />;
  else page = <HomePage />;

  const active = root === "produit" ? "" : root;

  return (
    <>
      <div className="bg" aria-hidden="true" />
      <main>{page}</main>
      <nav className="tabbar" aria-label="Navigation principale">
        {TABS.map(({ to, key, label, Icon }) => (
          <a key={to} href={href(to)} className={active === key ? "on" : ""} aria-current={active === key ? "page" : undefined}>
            <Icon />
            <span>{label}</span>
          </a>
        ))}
      </nav>
    </>
  );
}
