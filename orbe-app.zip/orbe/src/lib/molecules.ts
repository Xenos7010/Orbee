export type El =
  | "C"
  | "H"
  | "O"
  | "N"
  | "S"
  | "P"
  | "Na"
  | "Cl"
  | "Ca"
  | "Mg"
  | "K"
  | "Si";

export type Atom = { el: El; p: [number, number, number] };
export type Bond = { a: number; b: number; order: 1 | 2 | 3; ionic?: boolean };

export type Molecule = {
  id: string;
  name: string;
  formula: string;
  counts: Partial<Record<El, number>>;
  mass: number;
  family: string;
  blurb: string;
  schematic: boolean;
  atoms: Atom[];
  bonds: Bond[];
};

type V = [number, number, number];
type AtomIn = { el: El; p: V; hyd?: number };

export const ELEMENTS: Record<
  El,
  { name: string; mass: number; radius: number; color: string; role: string }
> = {
  C: {
    name: "Carbone",
    mass: 12.011,
    radius: 0.42,
    color: "#3a3a3e",
    role: "Squelette des molécules organiques.",
  },
  H: {
    name: "Hydrogène",
    mass: 1.008,
    radius: 0.26,
    color: "#f4f4f5",
    role: "Termine les liaisons libres du squelette.",
  },
  O: {
    name: "Oxygène",
    mass: 15.999,
    radius: 0.38,
    color: "#c4544c",
    role: "Alcools, carbonyles, eau, esters.",
  },
  N: {
    name: "Azote",
    mass: 14.007,
    radius: 0.4,
    color: "#4f6f96",
    role: "Amines, amides, bases azotées.",
  },
  S: {
    name: "Soufre",
    mass: 32.06,
    radius: 0.5,
    color: "#b89a55",
    role: "Sulfates, certains acides aminés.",
  },
  P: {
    name: "Phosphore",
    mass: 30.974,
    radius: 0.5,
    color: "#c47a45",
    role: "Phosphates, tête des phospholipides.",
  },
  Na: {
    name: "Sodium",
    mass: 22.99,
    radius: 0.52,
    color: "#8aa0b8",
    role: "Cation dissous, souvent avec le chlorure.",
  },
  Cl: {
    name: "Chlore",
    mass: 35.45,
    radius: 0.54,
    color: "#6f9a72",
    role: "Anion chlorure des sels et des eaux.",
  },
  Ca: {
    name: "Calcium",
    mass: 40.078,
    radius: 0.58,
    color: "#d7d2c8",
    role: "Cation divalent, minéral majeur de l'eau.",
  },
  Mg: {
    name: "Magnésium",
    mass: 24.305,
    radius: 0.5,
    color: "#9aa58a",
    role: "Cation divalent, souvent hexahydraté.",
  },
  K: {
    name: "Potassium",
    mass: 39.098,
    radius: 0.62,
    color: "#b07d8a",
    role: "Cation alcalin dissous.",
  },
  Si: {
    name: "Silicium",
    mass: 28.085,
    radius: 0.48,
    color: "#c2b8a4",
    role: "Silice dissoute, tétraèdre SiO4.",
  },
};

const VALENCE: Record<El, number> = {
  C: 4,
  H: 1,
  O: 2,
  N: 3,
  S: 2,
  P: 5,
  Na: 0,
  Cl: 0,
  Ca: 0,
  Mg: 0,
  K: 0,
  Si: 4,
};

const H_LEN: Partial<Record<El, number>> = { C: 1.09, O: 0.97, N: 1.01, S: 1.34, P: 1.4, Si: 1.48 };

function add(a: V, b: V): V {
  return [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
}
function sub(a: V, b: V): V {
  return [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
}
function mul(a: V, s: number): V {
  return [a[0] * s, a[1] * s, a[2] * s];
}
function len(a: V) {
  return Math.hypot(a[0], a[1], a[2]);
}
function norm(a: V): V {
  const l = len(a) || 1;
  return [a[0] / l, a[1] / l, a[2] / l];
}
function cross(a: V, b: V): V {
  return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
}

function hydrogenDirs(neighbors: V[], count: number): V[] {
  if (count <= 0) return [];
  const n = neighbors.map(norm).filter((v) => len(v) > 0.2);
  const perp = (axis: V): V => {
    const helper: V = Math.abs(axis[1]) < 0.85 ? [0, 1, 0] : [1, 0, 0];
    return norm(cross(axis, helper));
  };
  if (n.length === 0) {
    const tetra: V[] = [
      [1, 1, 1],
      [1, -1, -1],
      [-1, 1, -1],
      [-1, -1, 1],
    ];
    const base: V[] = tetra.map((v) => norm(v));
    return base.slice(0, count);
  }
  if (n.length === 1 && count === 1) {
    const axis = n[0];
    const u = perp(axis);
    const side = Math.sqrt(1 - 1 / 9);
    return [norm(add(mul(axis, -1 / 3), mul(u, side)))];
  }
  if (n.length === 1) {
    const axis = n[0];
    const u = perp(axis);
    const v = norm(cross(axis, u));
    const back = 1 / 3;
    const side = Math.sqrt(1 - back * back);
    const dirs: V[] = [];
    for (let i = 0; i < count; i++) {
      const ang = (Math.PI * 2 * i) / count;
      dirs.push(
        norm(add(mul(axis, -back), add(mul(u, Math.cos(ang) * side), mul(v, Math.sin(ang) * side)))),
      );
    }
    return dirs;
  }
  if (n.length === 2) {
    const away = norm(mul(add(n[0], n[1]), -1));
    if (count === 1) return [away];
    const u = norm(cross(n[0], n[1]));
    const spread = 0.85;
    return [
      norm(add(mul(away, Math.cos(spread / 2)), mul(u, Math.sin(spread / 2)))),
      norm(add(mul(away, Math.cos(spread / 2)), mul(u, -Math.sin(spread / 2)))),
    ].slice(0, count);
  }
  const away = norm(mul(n.slice(0, 3).reduce(add, [0, 0, 0] as V), -1));
  return [away];
}

function withHydrogens(atoms: AtomIn[], bonds: Bond[]): { atoms: Atom[]; bonds: Bond[] } {
  const nextAtoms: Atom[] = atoms.map((a) => ({ el: a.el, p: [...a.p] as V }));
  const nextBonds: Bond[] = bonds.map((b) => ({ ...b }));
  const neighbors: number[][] = atoms.map(() => []);
  const orderSum = atoms.map(() => 0);
  for (const b of bonds) {
    neighbors[b.a].push(b.b);
    neighbors[b.b].push(b.a);
    orderSum[b.a] += b.order;
    orderSum[b.b] += b.order;
  }
  for (let i = 0; i < atoms.length; i++) {
    const atom = atoms[i];
    const missing =
      atom.hyd !== undefined ? atom.hyd : Math.max(0, VALENCE[atom.el] - orderSum[i]);
    if (missing <= 0 || missing > 4) continue;
    const neigh = neighbors[i].map((j) => sub(atoms[j].p, atom.p));
    const dirs = hydrogenDirs(neigh, missing);
    const bondLen = H_LEN[atom.el] ?? 1.08;
    for (const d of dirs) {
      const hi = nextAtoms.length;
      nextAtoms.push({ el: "H", p: add(atom.p, mul(d, bondLen)) });
      nextBonds.push({ a: i, b: hi, order: 1 });
    }
  }
  return { atoms: nextAtoms, bonds: nextBonds };
}

function formulaOf(atoms: Atom[]): { formula: string; counts: Partial<Record<El, number>>; mass: number } {
  const counts: Partial<Record<El, number>> = {};
  for (const a of atoms) counts[a.el] = (counts[a.el] ?? 0) + 1;
  const order: El[] = ["C", "H"];
  const rest = (Object.keys(counts) as El[])
    .filter((el) => el !== "C" && el !== "H")
    .sort();
  const seq = [...order.filter((el) => counts[el]), ...rest];
  const formula = seq.map((el) => `${el}${counts[el]! > 1 ? counts[el] : ""}`).join("");
  const mass = atoms.reduce((s, a) => s + ELEMENTS[a.el].mass, 0);
  return { formula, counts, mass: Math.round(mass * 100) / 100 };
}

function compile(def: {
  id: string;
  name: string;
  family: string;
  blurb: string;
  schematic?: boolean;
  formula?: string;
  atoms: AtomIn[];
  bonds: Bond[];
  explicit?: boolean;
}): Molecule {
  const built = def.explicit
    ? {
        atoms: def.atoms.map((a) => ({ el: a.el, p: [...a.p] as V })),
        bonds: def.bonds.map((b) => ({ ...b })),
      }
    : withHydrogens(def.atoms, def.bonds);
  const meta = formulaOf(built.atoms);
  return {
    id: def.id,
    name: def.name,
    family: def.family,
    blurb: def.blurb,
    schematic: def.schematic ?? false,
    atoms: built.atoms,
    bonds: built.bonds,
    formula: def.formula ?? meta.formula,
    counts: meta.counts,
    mass: meta.mass,
  };
}

function ringOut(atoms: AtomIn[], index: number, na: number, nb: number, dist: number): V {
  const p = atoms[index].p;
  const mid = mul(add(sub(atoms[na].p, p), sub(atoms[nb].p, p)), 0.5);
  const dir = norm(mul(mid, -1));
  const lift: V = [dir[0], dir[1], dir[2] + 0.18];
  return add(p, mul(norm(lift), dist));
}

type Slot = "o1" | "o2" | "o3" | "o4";

function sugarRing(origin: V, rot: number, skip: Slot[] = []) {
  const atoms: AtomIn[] = [];
  for (let i = 0; i < 6; i++) {
    const a = rot + (Math.PI / 3) * i - Math.PI / 2;
    atoms.push({
      el: i === 5 ? "O" : "C",
      p: [
        origin[0] + Math.cos(a) * 1.5,
        origin[1] + Math.sin(a) * 1.38,
        origin[2] + (i % 2 === 0 ? 0.22 : -0.22),
      ],
    });
  }
  const bonds: Bond[] = [0, 1, 2, 3, 4, 5].map((i) => ({
    a: i,
    b: (i + 1) % 6,
    order: 1 as const,
  }));
  const slots: { o1: number; c1: number; c4: number; o4: number } = {
    c1: 0,
    o1: -1,
    c4: 3,
    o4: -1,
  };
  const addOh = (carbon: number, na: number, nb: number) => {
    const idx = atoms.length;
    atoms.push({ el: "O", p: ringOut(atoms, carbon, na, nb, 1.43) });
    bonds.push({ a: carbon, b: idx, order: 1 });
    return idx;
  };
  if (!skip.includes("o1")) slots.o1 = addOh(0, 1, 5);
  if (!skip.includes("o2")) addOh(1, 0, 2);
  if (!skip.includes("o3")) addOh(2, 1, 3);
  if (!skip.includes("o4")) slots.o4 = addOh(3, 2, 4);
  const c6 = atoms.length;
  atoms.push({ el: "C", p: ringOut(atoms, 4, 3, 5, 1.52) });
  bonds.push({ a: 4, b: c6, order: 1 });
  const o6 = atoms.length;
  const c6p = atoms[c6].p;
  atoms.push({ el: "O", p: add(c6p, [0.35, 0.85, 0.72]) });
  bonds.push({ a: c6, b: o6, order: 1 });
  return { atoms, bonds, slots };
}

function fructoseRing(origin: V, rot: number) {
  const atoms: AtomIn[] = [];
  for (let i = 0; i < 5; i++) {
    const a = rot + (i * 2 * Math.PI) / 5 - Math.PI / 2;
    atoms.push({
      el: i === 4 ? "O" : "C",
      p: [
        origin[0] + Math.cos(a) * 1.32,
        origin[1] + Math.sin(a) * 1.22,
        origin[2] + (i % 2 ? 0.16 : -0.12),
      ],
    });
  }
  // 0 C2, 1 C3, 2 C4, 3 C5, 4 ring O
  const bonds: Bond[] = [0, 1, 2, 3, 4].map((i) => ({
    a: i,
    b: (i + 1) % 5,
    order: 1 as const,
  }));
  const addOh = (carbon: number, na: number, nb: number) => {
    const idx = atoms.length;
    atoms.push({ el: "O", p: ringOut(atoms, carbon, na, nb, 1.4) });
    bonds.push({ a: carbon, b: idx, order: 1 });
    return idx;
  };
  addOh(1, 0, 2);
  addOh(2, 1, 3);
  const c1 = atoms.length;
  atoms.push({ el: "C", p: ringOut(atoms, 0, 1, 4, 1.5) });
  bonds.push({ a: 0, b: c1, order: 1 });
  const o1 = atoms.length;
  atoms.push({ el: "O", p: add(atoms[c1].p, [0.4, 0.7, 0.7]) });
  bonds.push({ a: c1, b: o1, order: 1 });
  const c6 = atoms.length;
  atoms.push({ el: "C", p: ringOut(atoms, 3, 2, 4, 1.5) });
  bonds.push({ a: 3, b: c6, order: 1 });
  const o6 = atoms.length;
  atoms.push({ el: "O", p: add(atoms[c6].p, [-0.2, 0.75, 0.65]) });
  bonds.push({ a: c6, b: o6, order: 1 });
  return { atoms, bonds, c2: 0 };
}

function merge(
  parts: { atoms: AtomIn[]; bonds: Bond[] }[],
  extra: Bond[] = [],
): { atoms: AtomIn[]; bonds: Bond[] } {
  const atoms: AtomIn[] = [];
  const bonds: Bond[] = [];
  const offsets: number[] = [];
  for (const p of parts) {
    offsets.push(atoms.length);
    atoms.push(...p.atoms);
    for (const b of p.bonds) bonds.push({ ...b, a: b.a + offsets[offsets.length - 1], b: b.b + offsets[offsets.length - 1] });
  }
  for (const b of extra) bonds.push(b);
  return { atoms, bonds };
}

function offsetBond(local: Bond, offset: number): Bond {
  return { ...local, a: local.a + offset, b: local.b + offset };
}

function polysaccharide(count: number, helical: boolean) {
  const built: ReturnType<typeof sugarRing>[] = [];
  for (let i = 0; i < count; i++) {
    const origin: V = helical
      ? [Math.cos(i * 0.85) * 1.1, i * 0.45, i * 3.55]
      : [i * 4.05, (i % 2) * 0.35, 0];
    const rot = helical ? i * 0.7 : i * Math.PI;
    const skip: Slot[] = [];
    if (i > 0) skip.push("o4");
    built.push(sugarRing(origin, rot, skip));
  }
  let acc = 0;
  const offsets = built.map((b) => {
    const o = acc;
    acc += b.atoms.length;
    return o;
  });
  const extra: Bond[] = [];
  for (let i = 0; i < count - 1; i++) {
    extra.push({
      a: built[i].slots.o1 + offsets[i],
      b: built[i + 1].slots.c4 + offsets[i + 1],
      order: 1,
    });
  }
  return merge(built, extra);
}

function sucrose() {
  const g = sugarRing([0, 0, 0], 0.2);
  const f = fructoseRing([3.55, 0.35, 0.15], 0.4);
  const off = g.atoms.length;
  return merge([g, f], [{ a: g.slots.o1, b: f.c2 + off, order: 1 }]);
}

function lactose() {
  const a = sugarRing([0, 0, 0], 0.15);
  const b = sugarRing([4.05, 0.2, 0.1], 0.9, ["o4"]);
  return merge([a, b], [{ a: a.slots.o1, b: b.slots.c4 + a.atoms.length, order: 1 }]);
}

function zigzagChain(n: number, origin: V, cisAt: number | null): { atoms: AtomIn[]; bonds: Bond[] } {
  const atoms: AtomIn[] = [];
  const bonds: Bond[] = [];
  let ySign = 1;
  for (let i = 0; i < n; i++) {
    const kink = cisAt !== null && i > cisAt ? 0.42 : 0;
    atoms.push({
      el: "C",
      p: [origin[0] + i * 1.27, origin[1] + ySign * 0.52 + kink, origin[2]],
    });
    if (i > 0) {
      const order: 1 | 2 = cisAt !== null && i === cisAt + 1 ? 2 : 1;
      bonds.push({ a: i - 1, b: i, order });
    }
    if (!(cisAt !== null && i === cisAt)) ySign *= -1;
  }
  return { atoms, bonds };
}

function oleic(): { atoms: AtomIn[]; bonds: Bond[] } {
  const chain = zigzagChain(18, [0, 0, 0], 8);
  // Convert C0 into a carboxylic acid: =O and –OH.
  const c0 = chain.atoms[0].p;
  const o = chain.atoms.length;
  chain.atoms.push({ el: "O", p: [c0[0] - 0.72, c0[1] - 1.05, c0[2] + 0.15] });
  const oh = chain.atoms.length;
  chain.atoms.push({ el: "O", p: [c0[0] - 0.85, c0[1] + 0.55, c0[2] + 0.85] });
  chain.bonds.push({ a: 0, b: o, order: 2 });
  chain.bonds.push({ a: 0, b: oh, order: 1 });
  return chain;
}

function esterArm(origin: V, carbons: number, cis: boolean): { atoms: AtomIn[]; bonds: Bond[]; link: number } {
  const atoms: AtomIn[] = [];
  const bonds: Bond[] = [];
  // bridging O is index 0, caller bonds it to glycerol. Carbonyl is index 1.
  atoms.push({ el: "O", p: origin });
  const carbonyl: V = [origin[0] + 1.28, origin[1], origin[2]];
  atoms.push({ el: "C", p: carbonyl });
  bonds.push({ a: 0, b: 1, order: 1 });
  atoms.push({ el: "O", p: [carbonyl[0] + 0.15, carbonyl[1] + 1.05, carbonyl[2] + 0.2] });
  bonds.push({ a: 1, b: 2, order: 2 });
  const chain = zigzagChain(carbons, [carbonyl[0] + 1.3, carbonyl[1] - 0.15, carbonyl[2]], cis ? 3 : null);
  const base = atoms.length;
  atoms.push(...chain.atoms);
  bonds.push(...chain.bonds.map((b) => offsetBond(b, base)));
  bonds.push({ a: 1, b: base, order: 1 });
  return { atoms, bonds, link: 0 };
}

function glyceride(chains: number[], cis: boolean[]): { atoms: AtomIn[]; bonds: Bond[] } {
  const atoms: AtomIn[] = [
    { el: "C", p: [0, 0, 0] },
    { el: "C", p: [0, 1.54, 0] },
    { el: "C", p: [0, 3.08, 0] },
  ];
  const bonds: Bond[] = [
    { a: 0, b: 1, order: 1 },
    { a: 1, b: 2, order: 1 },
  ];
  chains.forEach((n, i) => {
    const arm = esterArm([1.35, i * 1.54, 0.15], n, cis[i] ?? false);
    const base = atoms.length;
    atoms.push(...arm.atoms);
    bonds.push(...arm.bonds.map((b) => offsetBond(b, base)));
    bonds.push({ a: i, b: base + arm.link, order: 1 });
  });
  return { atoms, bonds };
}

function xanthine(methyls: { n1: boolean; n3: boolean; n7: boolean }) {
  const atoms: AtomIn[] = [];
  const N1: V = [-1.15, 0.7, 0];
  const C2: V = [0.05, 1.35, 0];
  const N3: V = [1.25, 0.7, 0];
  const C4: V = [1.15, -0.65, 0];
  const C5: V = [-0.15, -1.15, 0];
  const C6: V = [-1.3, -0.55, 0];
  atoms.push(
    { el: "N", p: N1, hyd: methyls.n1 ? 0 : 1 },
    { el: "C", p: C2, hyd: 0 },
    { el: "N", p: N3, hyd: 0 },
    { el: "C", p: C4, hyd: 0 },
    { el: "C", p: C5, hyd: 0 },
    { el: "C", p: C6, hyd: 0 },
    { el: "O", p: [0.05, 2.62, 0], hyd: 0 },
    { el: "O", p: [-2.55, -0.95, 0], hyd: 0 },
  );
  const bonds: Bond[] = [
    { a: 0, b: 1, order: 1 },
    { a: 1, b: 2, order: 1 },
    { a: 2, b: 3, order: 1 },
    { a: 3, b: 4, order: 2 },
    { a: 4, b: 5, order: 1 },
    { a: 5, b: 0, order: 1 },
    { a: 1, b: 6, order: 2 },
    { a: 5, b: 7, order: 2 },
  ];
  const pushMethyl = (from: number, p: V) => {
    if (from < 0) return;
    const idx = atoms.length;
    atoms.push({ el: "C", p, hyd: 3 });
    bonds.push({ a: from, b: idx, order: 1 });
  };
  if (methyls.n1) pushMethyl(0, [-2.15, 1.55, 0.2]);
  if (methyls.n3) pushMethyl(2, [2.45, 1.45, 0.15]);
  // Imidazole on C4–C5, growing downward.
  const n9 = atoms.length;
  atoms.push({ el: "N", p: [2.15, -1.55, 0], hyd: 0 });
  const c8 = atoms.length;
  atoms.push({ el: "C", p: [1.35, -2.7, 0], hyd: 1 });
  const n7 = atoms.length;
  atoms.push({ el: "N", p: [0.05, -2.45, 0], hyd: 0 });
  bonds.push({ a: 3, b: n9, order: 1 });
  bonds.push({ a: n9, b: c8, order: 1 });
  bonds.push({ a: c8, b: n7, order: 2 });
  bonds.push({ a: n7, b: 4, order: 1 });
  if (methyls.n7) pushMethyl(n7, [-1.05, -3.35, 0.2]);
  return { atoms, bonds };
}

function benzene(origin: V, rot: number) {
  const atoms: AtomIn[] = [];
  for (let i = 0; i < 6; i++) {
    const a = rot + (i * Math.PI) / 3;
    atoms.push({
      el: "C",
      p: [origin[0] + Math.cos(a) * 1.4, origin[1] + Math.sin(a) * 1.4, origin[2]],
    });
  }
  const bonds: Bond[] = [0, 1, 2, 3, 4, 5].map((i) => ({
    a: i,
    b: (i + 1) % 6,
    order: (i % 2 === 0 ? 2 : 1) as 1 | 2,
  }));
  return { atoms, bonds };
}

function vanillin() {
  const ring = benzene([0, 0, 0], Math.PI / 6);
  const atoms = ring.atoms;
  const bonds = ring.bonds;
  const place = (from: number, dist: number, el: El, order: 1 | 2): number => {
    const p = atoms[from].p;
    const dir = norm(p); // ring centered at origin
    const idx = atoms.length;
    atoms.push({ el, p: add(p, mul(dir, dist)) });
    bonds.push({ a: from, b: idx, order });
    return idx;
  };
  // C0 aldehyde, C1 hydroxy, C3 methoxy. Ring index 0 is angle PI/6.
  const ald = place(0, 1.48, "C", 1);
  const aldP = atoms[ald].p;
  const ox = atoms.length;
  const dir = norm(aldP);
  const side = norm(cross(dir, [0, 0, 1]));
  atoms.push({ el: "O", p: add(aldP, mul(side, 1.15)) });
  bonds.push({ a: ald, b: ox, order: 2 });
  place(1, 1.36, "O", 1);
  const methO = place(3, 1.36, "O", 1);
  const methP = atoms[methO].p;
  const methDir = norm(methP);
  const mc = atoms.length;
  atoms.push({ el: "C", p: add(methP, mul(methDir, 1.42)), hyd: 3 });
  bonds.push({ a: methO, b: mc, order: 1 });
  return { atoms, bonds };
}

function citric() {
  const atoms: AtomIn[] = [{ el: "C", p: [0, 0, 0] }];
  const bonds: Bond[] = [];
  atoms.push({ el: "O", p: [0, 1.42, 0] });
  bonds.push({ a: 0, b: 1, order: 1 });
  const carboxyl = (from: number, p: V, bend: V) => {
    const c = atoms.length;
    atoms.push({ el: "C", p });
    bonds.push({ a: from, b: c, order: 1 });
    atoms.push({ el: "O", p: add(p, bend) });
    bonds.push({ a: c, b: c + 1, order: 2 });
    atoms.push({ el: "O", p: add(p, [bend[1], -bend[0] * 0.2, 0.95]) });
    bonds.push({ a: c, b: c + 2, order: 1 });
    return c;
  };
  carboxyl(0, [1.52, -0.35, 0.1], [0.85, -0.85, 0.1]);
  const ch2a = atoms.length;
  atoms.push({ el: "C", p: [-1.35, 0.55, 0.35] });
  bonds.push({ a: 0, b: ch2a, order: 1 });
  carboxyl(ch2a, [-2.55, 1.25, -0.15], [-0.7, 0.85, 0]);
  const ch2b = atoms.length;
  atoms.push({ el: "C", p: [-0.85, -1.25, -0.25] });
  bonds.push({ a: 0, b: ch2b, order: 1 });
  carboxyl(ch2b, [-1.7, -2.4, 0.35], [-0.9, -0.4, 0.2]);
  return { atoms, bonds };
}

function tetra(center: V, r: number): V[] {
  return (
    [
      [1, 1, 1],
      [1, -1, -1],
      [-1, 1, -1],
      [-1, -1, 1],
    ] as V[]
  ).map((v) => add(center, mul(norm(v), r)));
}

function phosphoric() {
  const o = tetra([0, 0, 0], 1.55);
  const atoms: AtomIn[] = [
    { el: "P", p: [0, 0, 0] },
    { el: "O", p: o[0] },
    { el: "O", p: o[1] },
    { el: "O", p: o[2] },
    { el: "O", p: o[3] },
  ];
  const bonds: Bond[] = [
    { a: 0, b: 1, order: 2 },
    { a: 0, b: 2, order: 1 },
    { a: 0, b: 3, order: 1 },
    { a: 0, b: 4, order: 1 },
  ];
  return { atoms, bonds };
}

function sulfate() {
  const o = tetra([0, 0, 0], 1.5);
  const atoms: AtomIn[] = [
    { el: "S", p: [0, 0, 0], hyd: 0 },
    ...o.map((p) => ({ el: "O" as const, p, hyd: 0 })),
  ];
  const bonds: Bond[] = [1, 2, 3, 4].map((i) => ({ a: 0, b: i, order: 1 as const, ionic: true }));
  return { atoms, bonds };
}

function silicate() {
  const o = tetra([0, 0, 0], 1.62);
  const atoms: AtomIn[] = [
    { el: "Si", p: [0, 0, 0], hyd: 0 },
    ...o.map((p) => ({ el: "O" as const, p, hyd: 0 })),
  ];
  const bonds: Bond[] = [1, 2, 3, 4].map((i) => ({ a: 0, b: i, order: 1 as const }));
  return { atoms, bonds };
}

function bicarbonate() {
  const atoms: AtomIn[] = [
    { el: "C", p: [0, 0, 0], hyd: 0 },
    { el: "O", p: [0, 1.25, 0], hyd: 0 },
    { el: "O", p: [-1.15, -0.7, 0], hyd: 0 },
    { el: "O", p: [1.15, -0.7, 0.1] },
  ];
  const bonds: Bond[] = [
    { a: 0, b: 1, order: 2 },
    { a: 0, b: 2, order: 1 },
    { a: 0, b: 3, order: 1 },
  ];
  return { atoms, bonds };
}

function aqua(el: El, coord: 4 | 6, dist: number): { atoms: AtomIn[]; bonds: Bond[] } {
  const axes: V[] =
    coord === 6
      ? [
          [1, 0, 0],
          [-1, 0, 0],
          [0, 1, 0],
          [0, -1, 0],
          [0, 0, 1],
          [0, 0, -1],
        ]
      : ([
          [1, 1, 1],
          [1, -1, -1],
          [-1, 1, -1],
          [-1, -1, 1],
        ] as V[]).map(norm);
  const atoms: AtomIn[] = [{ el, p: [0, 0, 0], hyd: 0 }];
  const bonds: Bond[] = [];
  axes.forEach((d, i) => {
    atoms.push({ el: "O", p: mul(norm(d), dist), hyd: 2 });
    bonds.push({ a: 0, b: i + 1, order: 1, ionic: true });
  });
  return { atoms, bonds };
}

function saltCrystal() {
  const atoms: AtomIn[] = [];
  const s = 2.82;
  for (let x = 0; x < 3; x++) {
    for (let y = 0; y < 3; y++) {
      for (let z = 0; z < 3; z++) {
        atoms.push({
          el: (x + y + z) % 2 === 0 ? "Na" : "Cl",
          p: [(x - 1) * s, (y - 1) * s, (z - 1) * s],
          hyd: 0,
        });
      }
    }
  }
  const bonds: Bond[] = [];
  const idx = (x: number, y: number, z: number) => x * 9 + y * 3 + z;
  for (let x = 0; x < 3; x++) {
    for (let y = 0; y < 3; y++) {
      for (let z = 0; z < 3; z++) {
        const i = idx(x, y, z);
        if (x + 1 < 3) bonds.push({ a: i, b: idx(x + 1, y, z), order: 1, ionic: true });
        if (y + 1 < 3) bonds.push({ a: i, b: idx(x, y + 1, z), order: 1, ionic: true });
        if (z + 1 < 3) bonds.push({ a: i, b: idx(x, y, z + 1), order: 1, ionic: true });
      }
    }
  }
  return { atoms, bonds };
}

function helix() {
  const atoms: AtomIn[] = [];
  const bonds: Bond[] = [];
  let prevC = -1;
  for (let i = 0; i < 12; i++) {
    const t = i * 1.15;
    const y = i * 1.32;
    const N: V = [Math.cos(t) * 2.15, y, Math.sin(t) * 2.15];
    const CA: V = [Math.cos(t + 0.42) * 2.2, y + 0.46, Math.sin(t + 0.42) * 2.2];
    const C: V = [Math.cos(t + 0.82) * 2.05, y + 0.92, Math.sin(t + 0.82) * 2.05];
    const O: V = [Math.cos(t + 0.82) * 3.2, y + 0.92, Math.sin(t + 0.82) * 3.2];
    const ni = atoms.length;
    atoms.push({ el: "N", p: N, hyd: i === 0 ? 2 : 1 });
    atoms.push({ el: "C", p: CA, hyd: 1 });
    atoms.push({ el: "C", p: C, hyd: 0 });
    atoms.push({ el: "O", p: O, hyd: 0 });
    bonds.push({ a: ni, b: ni + 1, order: 1 });
    bonds.push({ a: ni + 1, b: ni + 2, order: 1 });
    bonds.push({ a: ni + 2, b: ni + 3, order: 2 });
    if (prevC >= 0) bonds.push({ a: prevC, b: ni, order: 1 });
    prevC = ni + 2;
  }
  return { atoms, bonds };
}

function lecithin() {
  const g = glyceride([5, 5], [false, true]);
  // Replace nothing: glyceride with 2 chains leaves C2 (index 2) with only one carbon bond.
  // Attach phosphate head to glycerol C2.
  const atoms = g.atoms;
  const bonds = g.bonds;
  const bridge = atoms.length;
  atoms.push({ el: "O", p: [1.35, 3.08, 0.2] });
  bonds.push({ a: 2, b: bridge, order: 1 });
  const P = atoms.length;
  atoms.push({ el: "P", p: [2.7, 3.55, 0.35], hyd: 0 });
  bonds.push({ a: bridge, b: P, order: 1 });
  const od = atoms.length;
  atoms.push({ el: "O", p: [2.55, 4.95, 0.85], hyd: 0 });
  bonds.push({ a: P, b: od, order: 2 });
  const om = atoms.length;
  atoms.push({ el: "O", p: [3.15, 2.55, 1.45], hyd: 0 });
  bonds.push({ a: P, b: om, order: 1, ionic: true });
  const oc = atoms.length;
  atoms.push({ el: "O", p: [3.85, 4.15, -0.55] });
  bonds.push({ a: P, b: oc, order: 1 });
  const cA = atoms.length;
  atoms.push({ el: "C", p: [5.05, 4.55, -0.15] });
  bonds.push({ a: oc, b: cA, order: 1 });
  const cB = atoms.length;
  atoms.push({ el: "C", p: [6.15, 3.85, 0.45] });
  bonds.push({ a: cA, b: cB, order: 1 });
  const N = atoms.length;
  atoms.push({ el: "N", p: [7.35, 4.35, 0.15], hyd: 0 });
  bonds.push({ a: cB, b: N, order: 1 });
  const methyls: V[] = [
    [8.35, 3.45, 0.75],
    [7.15, 5.55, 0.95],
    [7.85, 4.55, -1.25],
  ];
  for (const p of methyls) {
    const i = atoms.length;
    atoms.push({ el: "C", p, hyd: 3 });
    bonds.push({ a: N, b: i, order: 1 });
  }
  return { atoms, bonds };
}

function maltol() {
  // gamma-pyrone-like ring: O, C, C(=O adjacent simplified), C, C, C
  const atoms: AtomIn[] = [];
  for (let i = 0; i < 6; i++) {
    const a = -Math.PI / 2 + (i * Math.PI) / 3;
    atoms.push({
      el: i === 0 ? "O" : "C",
      p: [Math.cos(a) * 1.4, Math.sin(a) * 1.4, 0],
    });
  }
  const bonds: Bond[] = [
    { a: 0, b: 1, order: 1 },
    { a: 1, b: 2, order: 2 },
    { a: 2, b: 3, order: 1 },
    { a: 3, b: 4, order: 2 },
    { a: 4, b: 5, order: 1 },
    { a: 5, b: 0, order: 1 },
  ];
  // carbonyl on C2 (index 2)
  atoms.push({ el: "O", p: add(atoms[2].p, norm(atoms[2].p)[0] ? mul(norm(atoms[2].p), 1.22) : [1.22, 0, 0]) });
  bonds.push({ a: 2, b: 6, order: 2 });
  // OH on C3 (index 3)
  atoms.push({ el: "O", p: add(atoms[3].p, mul(norm(atoms[3].p), 1.36)) });
  bonds.push({ a: 3, b: 7, order: 1 });
  // methyl on C6-ish index 5? maltol methyl is next to ring oxygen. Use index 1.
  atoms.push({ el: "C", p: add(atoms[1].p, mul(norm(atoms[1].p), 1.5)), hyd: 3 });
  bonds.push({ a: 1, b: 8, order: 1 });
  return { atoms, bonds };
}

function lycopene() {
  const atoms: AtomIn[] = [];
  const bonds: Bond[] = [];
  const n = 16;
  let ySign = 1;
  for (let i = 0; i < n; i++) {
    atoms.push({
      el: "C",
      p: [i * 1.28, ySign * 0.46, 0],
    });
    if (i > 0) bonds.push({ a: i - 1, b: i, order: i % 2 === 0 ? 2 : 1 });
    ySign *= -1;
    if (i > 1 && i < n - 1 && i % 4 === 2) {
      const m = atoms.length;
      atoms.push({ el: "C", p: [i * 1.28, ySign * 1.15, 0.35], hyd: 3 });
      bonds.push({ a: i, b: m, order: 1 });
    }
  }
  return { atoms, bonds };
}

function alanine() {
  const atoms: AtomIn[] = [
    { el: "N", p: [-1.45, 0.4, 0] },
    { el: "C", p: [0, 0, 0] },
    { el: "C", p: [0.85, 1.15, 0.2], hyd: 3 },
    { el: "C", p: [0.7, -1.25, 0] },
    { el: "O", p: [0.15, -2.35, 0.15] },
    { el: "O", p: [2.05, -1.25, 0.1] },
  ];
  const bonds: Bond[] = [
    { a: 0, b: 1, order: 1 },
    { a: 1, b: 2, order: 1 },
    { a: 1, b: 3, order: 1 },
    { a: 3, b: 4, order: 2 },
    { a: 3, b: 5, order: 1 },
  ];
  return { atoms, bonds };
}

function co2(): { atoms: AtomIn[]; bonds: Bond[] } {
  return {
    atoms: [
      { el: "O", p: [-1.16, 0, 0], hyd: 0 },
      { el: "C", p: [0, 0, 0], hyd: 0 },
      { el: "O", p: [1.16, 0, 0], hyd: 0 },
    ],
    bonds: [
      { a: 0, b: 1, order: 2 },
      { a: 1, b: 2, order: 2 },
    ],
  };
}

function water(): Molecule {
  return compile({
    id: "eau",
    name: "Eau",
    family: "Minéral",
    blurb: "Molécule coudée. Deux liaisons O–H et deux doublets libres, à l'origine de la liaison hydrogène.",
    explicit: true,
    atoms: [
      { el: "O", p: [0, 0, 0] },
      { el: "H", p: [0.76, 0.59, 0] },
      { el: "H", p: [-0.76, 0.59, 0] },
    ],
    bonds: [
      { a: 0, b: 1, order: 1 },
      { a: 0, b: 2, order: 1 },
    ],
  });
}

const glucoseBuilt = sugarRing([0, 0, 0], 0);

export const MOLECULES: Record<string, Molecule> = {
  eau: water(),
  co2: compile({
    id: "co2",
    name: "Dioxyde de carbone",
    family: "Gaz",
    blurb: "Molécule linéaire. C'est elle qui donne la pétillance une fois dissoute.",
    ...co2(),
  }),
  saccharose: compile({
    id: "saccharose",
    name: "Saccharose",
    family: "Sucre",
    blurb: "Glucose et fructose liés. C'est le sucre de table, presque entièrement calorique.",
    ...sucrose(),
  }),
  glucose: compile({
    id: "glucose",
    name: "Glucose",
    family: "Sucre",
    blurb: "Sucre simple en cycle à six. Unité de base de l'amidon et de la cellulose.",
    ...glucoseBuilt,
  }),
  oleique: compile({
    id: "oleique",
    name: "Acide oléique",
    family: "Lipide",
    blurb: "Acide gras à 18 carbones avec un coude cis. Majoritaire dans la noisette et l'olive.",
    ...oleic(),
  }),
  triglyceride: compile({
    id: "triglyceride",
    name: "Triglycéride",
    family: "Lipide",
    blurb: "Trois chaînes grasses sur un glycérol. Les chaînes du modèle sont raccourcies pour rester lisibles.",
    schematic: true,
    ...glyceride([7, 7, 7], [false, true, false]),
  }),
  cafeine: compile({
    id: "cafeine",
    name: "Caféine",
    family: "Alcaloïde",
    blurb: "Deux cycles azotés et trois méthyles. Stimulant présent dans le cola, le café et le cacao.",
    ...xanthine({ n1: true, n3: true, n7: true }),
  }),
  theobromine: compile({
    id: "theobromine",
    name: "Théobromine",
    family: "Alcaloïde",
    blurb: "Cousine de la caféine, typique du cacao. Il lui manque le méthyle porté par l'azote N1.",
    ...xanthine({ n1: false, n3: true, n7: true }),
  }),
  vanilline: compile({
    id: "vanilline",
    name: "Vanilline",
    family: "Arôme",
    blurb: "Cycle benzénique, aldéhyde, méthoxy et hydroxyle. C'est l'arôme principal de la vanille.",
    ...vanillin(),
  }),
  citrique: compile({
    id: "citrique",
    name: "Acide citrique",
    family: "Acide",
    blurb: "Trois fonctions acide autour d'un carbone porteur d'un alcool. Acidifiant très répandu.",
    ...citric(),
  }),
  phosphorique: compile({
    id: "phosphorique",
    name: "Acide phosphorique",
    family: "Acide",
    blurb: "Phosphore au centre d'un tétraèdre d'oxygènes. Acidifiant caractéristique des colas.",
    formula: "H3PO4",
    ...phosphoric(),
  }),
  nacl: compile({
    id: "nacl",
    name: "Chlorure de sodium",
    family: "Sel",
    blurb: "Réseau ionique cubique. Chaque sodium est entouré de chlorures, et inversement.",
    formula: "NaCl",
    schematic: true,
    ...saltCrystal(),
  }),
  lactose: compile({
    id: "lactose",
    name: "Lactose",
    family: "Sucre",
    blurb: "Sucre du lait : deux cycles reliés. Le second cycle représente ici le galactose de façon simplifiée.",
    schematic: true,
    ...lactose(),
  }),
  amidon: compile({
    id: "amidon",
    name: "Amylose",
    family: "Glucide",
    blurb: "Fragment d'amidon : trois glucoses en chaîne. Dans le grain, cette chaîne est des centaines de fois plus longue.",
    schematic: true,
    ...polysaccharide(3, true),
  }),
  cellulose: compile({
    id: "cellulose",
    name: "Cellulose",
    family: "Fibre",
    blurb: "Fragment linéaire de cellulose. Les cycles se retournent d'une unité à l'autre, d'où la fibre rigide.",
    schematic: true,
    ...polysaccharide(3, false),
  }),
  lycopene: compile({
    id: "lycopene",
    name: "Lycopène",
    family: "Pigment",
    blurb: "Longue chaîne de doubles liaisons conjuguées, raccourcie ici. C'est le rouge de la tomate.",
    schematic: true,
    ...lycopene(),
  }),
  lecithine: compile({
    id: "lecithine",
    name: "Lécithine",
    family: "Émulsifiant",
    blurb: "Deux queues grasses, un phosphate et une choline. La tête aime l'eau, les queues aiment le gras.",
    schematic: true,
    ...lecithin(),
  }),
  maltol: compile({
    id: "maltol",
    name: "Maltol",
    family: "Arôme",
    blurb: "Petite molécule au parfum de caramel. Sert de repère pour le colorant caramel, mélange bien plus complexe.",
    schematic: true,
    ...maltol(),
  }),
  helix: compile({
    id: "helix",
    name: "Fragment peptidique",
    family: "Protéine",
    blurb: "Squelette d'une hélice : azote, carbone alpha, carbonyle. Les chaînes latérales ne sont pas dessinées.",
    schematic: true,
    ...helix(),
  }),
  calcium: compile({
    id: "calcium",
    name: "Calcium hydraté",
    family: "Minéral",
    blurb: "Ion calcium entouré de six molécules d'eau, géométrie courante en solution.",
    formula: "[Ca(H2O)6]2+",
    schematic: true,
    ...aqua("Ca", 6, 2.35),
  }),
  magnesium: compile({
    id: "magnesium",
    name: "Magnésium hydraté",
    family: "Minéral",
    blurb: "Ion magnésium hexahydraté. Plus petit que le calcium, il tient l'eau de plus près.",
    formula: "[Mg(H2O)6]2+",
    schematic: true,
    ...aqua("Mg", 6, 2.05),
  }),
  sodium: compile({
    id: "sodium",
    name: "Sodium hydraté",
    family: "Minéral",
    blurb: "Cation sodium entouré de quatre eaux. Dans l'eau minérale, il reste très minoritaire.",
    formula: "[Na(H2O)4]+",
    schematic: true,
    ...aqua("Na", 4, 2.3),
  }),
  potassium: compile({
    id: "potassium",
    name: "Potassium hydraté",
    family: "Minéral",
    blurb: "Cation potassium, plus volumineux que le sodium, lui aussi dissous.",
    formula: "[K(H2O)4]+",
    schematic: true,
    ...aqua("K", 4, 2.7),
  }),
  chlorure: compile({
    id: "chlorure",
    name: "Chlorure hydraté",
    family: "Minéral",
    blurb: "Anion chlorure entouré d'eau. Associé au sodium, il forme le sel de table.",
    formula: "[Cl(H2O)4]−",
    schematic: true,
    ...aqua("Cl", 4, 3.1),
  }),
  bicarbonate: compile({
    id: "bicarbonate",
    name: "Hydrogénocarbonate",
    family: "Minéral",
    blurb: "Anion HCO3−, largement majoritaire dans le résidu sec de l'Evian.",
    formula: "HCO3−",
    ...bicarbonate(),
  }),
  sulfate: compile({
    id: "sulfate",
    name: "Sulfate",
    family: "Minéral",
    blurb: "Anion SO4 2−, tétraèdre régulier. Présent en petite quantité dans les eaux minérales.",
    formula: "SO42−",
    ...sulfate(),
  }),
  silice: compile({
    id: "silice",
    name: "Silicate",
    family: "Minéral",
    blurb: "Tétraèdre SiO4, brique de la silice dissoute. Modèle de l'unité, pas d'un quartz entier.",
    formula: "SiO4",
    schematic: true,
    ...silicate(),
  }),
  organique: compile({
    id: "organique",
    name: "Fragment organique",
    family: "Modèle",
    blurb: "Alanine, comme repère. Ce n'est pas la structure réelle de l'ingrédient quand elle n'est pas identifiée.",
    schematic: true,
    ...alanine(),
  }),
};

const e = (el: El, x: number, y: number, z: number): Atom => ({ el, p: [x, y, z] });

MOLECULES.o2 = compile({
  id: "o2",
  name: "Dioxygène",
  family: "Gaz",
  blurb: "Deux atomes d'oxygène reliés par une double liaison. Il représente environ 21 % de l'air et sert à respirer.",
  explicit: true,
  atoms: [e("O", -0.6, 0, 0), e("O", 0.6, 0, 0)],
  bonds: [{ a: 0, b: 1, order: 2 }],
});

MOLECULES.n2 = compile({
  id: "n2",
  name: "Diazote",
  family: "Gaz",
  blurb: "Deux atomes d'azote unis par une triple liaison, très solide. C'est pourquoi l'azote de l'air réagit si peu. Il fait 78 % de l'air.",
  explicit: true,
  atoms: [e("N", -0.55, 0, 0), e("N", 0.55, 0, 0)],
  bonds: [{ a: 0, b: 1, order: 3 }],
});

MOLECULES.ch4 = compile({
  id: "ch4",
  name: "Méthane",
  family: "Gaz",
  blurb: "Un carbone au centre d'un tétraèdre de quatre hydrogènes. C'est le principal composant du gaz naturel.",
  explicit: true,
  atoms: [
    e("C", 0, 0, 0),
    e("H", 0.63, 0.63, 0.63),
    e("H", 0.63, -0.63, -0.63),
    e("H", -0.63, 0.63, -0.63),
    e("H", -0.63, -0.63, 0.63),
  ],
  bonds: [
    { a: 0, b: 1, order: 1 },
    { a: 0, b: 2, order: 1 },
    { a: 0, b: 3, order: 1 },
    { a: 0, b: 4, order: 1 },
  ],
});

MOLECULES.nh3 = compile({
  id: "nh3",
  name: "Ammoniac",
  family: "Gaz",
  formula: "NH3",
  blurb: "Une petite pyramide : un azote et trois hydrogènes. Il sert à fabriquer les engrais.",
  explicit: true,
  atoms: [e("N", 0, 0, 0), e("H", 0.94, 0, -0.38), e("H", -0.47, 0.814, -0.38), e("H", -0.47, -0.814, -0.38)],
  bonds: [
    { a: 0, b: 1, order: 1 },
    { a: 0, b: 2, order: 1 },
    { a: 0, b: 3, order: 1 },
  ],
});

/** Molécules à montrer dans la bibliothèque (on cache le modèle générique). */
export const LIBRARY_ORDER = [
  "eau", "o2", "n2", "co2", "ch4", "nh3",
  "glucose", "saccharose", "lactose", "amidon", "cellulose",
  "oleique", "triglyceride", "lecithine",
  "cafeine", "theobromine", "vanilline", "maltol", "lycopene",
  "citrique", "phosphorique", "bicarbonate", "sulfate", "silice",
  "nacl", "sodium", "potassium", "calcium", "magnesium", "chlorure",
  "helix",
];

export function getMolecule(id: string): Molecule {
  return MOLECULES[id] ?? MOLECULES.organique;
}
