import type { Nutriments } from "./types";

export type NutrientKey = Exclude<keyof Nutriments, "energyKj">;

export const NUTRIENT_ROWS: {
  key: NutrientKey;
  label: string;
  unit: string;
  ri: number;
  indent?: boolean;
}[] = [
  { key: "energyKcal", label: "Énergie", unit: "kcal", ri: 2000 },
  { key: "fat", label: "Matières grasses", unit: "g", ri: 70 },
  { key: "saturatedFat", label: "dont saturés", unit: "g", ri: 20, indent: true },
  { key: "carbohydrates", label: "Glucides", unit: "g", ri: 260 },
  { key: "sugars", label: "dont sucres", unit: "g", ri: 90, indent: true },
  { key: "fiber", label: "Fibres", unit: "g", ri: 25 },
  { key: "proteins", label: "Protéines", unit: "g", ri: 50 },
  { key: "salt", label: "Sel", unit: "g", ri: 6 },
];

export function scaleNutriment(value: number | null, grams: number): number | null {
  if (value == null) return null;
  return (value * grams) / 100;
}

export function formatAmount(value: number | null, unit: string): string {
  if (value == null || Number.isNaN(value)) return "—";
  const abs = Math.abs(value);
  const digits = abs >= 100 ? 0 : abs >= 10 ? 1 : 2;
  return `${new Intl.NumberFormat("fr-FR", { maximumFractionDigits: digits, minimumFractionDigits: 0 }).format(value)} ${unit}`;
}

export function formatPrice(value: number, currency = "EUR"): string {
  try {
    return new Intl.NumberFormat("fr-FR", { style: "currency", currency }).format(value);
  } catch {
    return `${value.toFixed(2)} ${currency}`;
  }
}

export function median(values: number[]): number | null {
  if (!values.length) return null;
  const s = [...values].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

export function parseServingGrams(serving: string | null | undefined): number | null {
  if (!serving) return null;
  const m = serving.replace(",", ".").match(/(\d+(?:\.\d+)?)\s*(kg|g|ml|cl|l)\b/i);
  if (!m) return null;
  const n = Number(m[1]);
  if (!Number.isFinite(n) || n <= 0) return null;
  const u = m[2].toLowerCase();
  if (u === "kg" || u === "l") return n * 1000;
  if (u === "cl") return n * 10;
  return n;
}

export function placeLine(countries: string): string {
  const parts = countries
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  if (!parts.length) return "";
  if (parts.length <= 3) return parts.join(", ");
  if (parts.some((p) => /france/i.test(p))) return `France · ${parts.length} pays`;
  return `${parts.slice(0, 2).join(", ")} · ${parts.length} pays`;
}
