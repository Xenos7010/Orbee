import {
  cleanCategory,
  describeAdditive,
  frenchName,
  makeIngredients,
  moleculeFor,
  splitList,
  translateLabel,
} from "./ingredients";
import { parseServingGrams } from "./nutrition";
import type { Ingredient, Nutriments, PricePoint, Product, ScoreLetter, SearchHit } from "./types";

type OffIngredient = {
  id?: string;
  text?: string;
  percent?: number | null;
  percent_estimate?: number | null;
  vegan?: string | null;
  vegetarian?: string | null;
  from_palm_oil?: string | null;
};

type OffProduct = {
  product_name?: string;
  product_name_fr?: string;
  generic_name_fr?: string;
  generic_name?: string;
  brands?: string;
  quantity?: string;
  nutriscore_grade?: string;
  nova_group?: number | string;
  ecoscore_grade?: string;
  ingredients_text_fr?: string;
  ingredients_text?: string;
  allergens?: string;
  traces?: string;
  additives_tags?: string[];
  labels_tags?: string[];
  categories_tags_fr?: string[];
  categories?: string;
  origins?: string;
  countries?: string;
  packaging_text_fr?: string;
  manufacturing_places?: string;
  serving_size?: string;
  image_front_url?: string;
  ingredients?: OffIngredient[];
  nutriments?: Record<string, number | string | undefined>;
};

function score(value: unknown): ScoreLetter | null {
  if (typeof value !== "string") return null;
  const v = value.toLowerCase();
  if (v === "a" || v === "b" || v === "c" || v === "d" || v === "e") return v;
  return null;
}

function num(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() && Number.isFinite(Number(value))) return Number(value);
  return null;
}

function diet(value: unknown): "yes" | "no" | "maybe" | null {
  if (value === "yes" || value === "no" || value === "maybe") return value;
  return null;
}

function nutrimentsOf(raw: OffProduct["nutriments"]): Nutriments {
  const n = raw ?? {};
  return {
    energyKcal: num(n["energy-kcal_100g"]),
    energyKj: num(n["energy-kj_100g"]),
    fat: num(n.fat_100g),
    saturatedFat: num(n["saturated-fat_100g"]),
    carbohydrates: num(n.carbohydrates_100g),
    sugars: num(n.sugars_100g),
    fiber: num(n.fiber_100g),
    proteins: num(n.proteins_100g),
    salt: num(n.salt_100g),
  };
}

function ingredientsOf(list: OffIngredient[] | undefined, barcode: string): Ingredient[] {
  const top = (list ?? []).filter((i) => i.text || i.id).slice(0, 14);
  if (!top.length) return [];
  return makeIngredients(
    top.map((i) => {
      const id = i.id ?? null;
      const name = frenchName(i.text ?? "", id);
      const declared = typeof i.percent === "number" && i.percent > 0 ? i.percent : null;
      const estimate =
        declared == null && typeof i.percent_estimate === "number" && i.percent_estimate > 0
          ? i.percent_estimate
          : null;
      return {
        name,
        percent: declared ?? estimate,
        estimated: declared == null,
        offId: id,
        moleculeId: moleculeFor(name, id),
        vegan: diet(i.vegan),
        vegetarian: diet(i.vegetarian),
        fromPalmOil: i.from_palm_oil === "yes",
      };
    }),
    barcode,
  );
}

export function parseOffProduct(barcode: string, raw: OffProduct): Product | null {
  const name = (raw.product_name_fr || raw.product_name || "").trim();
  if (!name) return null;
  const ingredients = ingredientsOf(raw.ingredients, barcode);
  const novaRaw = num(raw.nova_group);
  const nova = novaRaw && novaRaw >= 1 && novaRaw <= 4 ? novaRaw : null;
  const labels = (raw.labels_tags ?? []).map(translateLabel).filter((v): v is string => Boolean(v));
  const categories = (raw.categories_tags_fr?.length ? raw.categories_tags_fr : (raw.categories ?? "").split(","))
    .map((t) => cleanCategory(String(t)))
    .filter((v): v is string => Boolean(v))
    .filter((v, i, arr) => arr.findIndex((x) => x.toLowerCase() === v.toLowerCase()) === i)
    .slice(0, 6);
  const servingSize = raw.serving_size?.trim() || null;
  return {
    barcode,
    name,
    brand: (raw.brands ?? "").split(",")[0]?.trim() || "",
    quantity: (raw.quantity ?? "").trim(),
    genericName: (raw.generic_name_fr || raw.generic_name || "").trim(),
    image: raw.image_front_url || null,
    categories,
    labels: labels.filter((v, i, arr) => arr.indexOf(v) === i).slice(0, 8),
    origins: (raw.origins ?? "").trim(),
    countries: (raw.countries ?? "").trim(),
    packaging: (raw.packaging_text_fr ?? "").trim(),
    manufacturing: (raw.manufacturing_places ?? "").trim(),
    ingredientsText: (raw.ingredients_text_fr || raw.ingredients_text || "").trim(),
    ingredients,
    matter: null,
    matterLabel: null,
    allergens: splitList(raw.allergens),
    traces: splitList(raw.traces),
    additives: (raw.additives_tags ?? []).slice(0, 12).map(describeAdditive),
    nutriments: nutrimentsOf(raw.nutriments),
    nutriscore: score(raw.nutriscore_grade),
    nova,
    ecoscore: score(raw.ecoscore_grade),
    servingSize,
    servingGrams: parseServingGrams(servingSize),
    prices: [],
    palmOil: ingredients.some((i) => i.fromPalmOil),
    source: "registre",
  };
}

type PriceItem = {
  price?: number;
  currency?: string;
  date?: string;
  location?: {
    osm_brand?: string | null;
    osm_name?: string | null;
    osm_address_city?: string | null;
  };
};

export function parsePrices(payload: unknown): PricePoint[] {
  const items = (payload as { items?: PriceItem[] } | null)?.items ?? [];
  const points: PricePoint[] = [];
  for (const item of items) {
    if (typeof item.price !== "number" || !Number.isFinite(item.price) || item.price <= 0) continue;
    const currency = (item.currency || "EUR").toUpperCase();
    if (currency !== "EUR") continue;
    points.push({
      price: item.price,
      currency,
      store: item.location?.osm_brand || item.location?.osm_name || null,
      city: item.location?.osm_address_city || null,
      date: item.date || null,
      indicative: false,
    });
  }
  return points.slice(0, 8);
}

export function parseSearch(payload: unknown): SearchHit[] {
  const products = (payload as { products?: Record<string, unknown>[] } | null)?.products ?? [];
  const hits: SearchHit[] = [];
  for (const p of products) {
    const barcode = String(p.code ?? "").replace(/\D/g, "");
    const name = String(p.product_name_fr || p.product_name || "").trim();
    if (!/^\d{8,14}$/.test(barcode) || !name) continue;
    hits.push({
      barcode,
      name,
      brand: String(p.brands ?? "").split(",")[0]?.trim() ?? "",
      quantity: String(p.quantity ?? ""),
      image: typeof p.image_front_small_url === "string" ? p.image_front_small_url : null,
      nutriscore: score(p.nutriscore_grade),
    });
  }
  return hits.slice(0, 8);
}

export function mergeProduct(local: Product | null, remote: Product | null): Product | null {
  if (!remote) return local;
  if (!local) return remote;
  return {
    ...remote,
    name: remote.name || local.name,
    brand: remote.brand || local.brand,
    genericName: remote.genericName || local.genericName,
    image: remote.image || local.image,
    quantity: remote.quantity || local.quantity,
    ingredientsText: remote.ingredientsText || local.ingredientsText,
    ingredients: remote.ingredients.length ? remote.ingredients : local.ingredients,
    matter: local.matter,
    matterLabel: local.matterLabel,
    additives: remote.additives.length ? remote.additives : local.additives,
    allergens: remote.allergens.length ? remote.allergens : local.allergens,
    traces: remote.traces.length ? remote.traces : local.traces,
    prices: remote.prices.length ? remote.prices : local.prices,
    servingSize: remote.servingSize || local.servingSize,
    servingGrams: remote.servingGrams ?? local.servingGrams,
    nutriscore: remote.nutriscore ?? local.nutriscore,
    nova: remote.nova ?? local.nova,
    ecoscore: remote.ecoscore ?? local.ecoscore,
    nutriments: remote.nutriments.energyKcal == null ? local.nutriments : remote.nutriments,
    origins: remote.origins || local.origins,
    packaging: remote.packaging || local.packaging,
    manufacturing: remote.manufacturing || local.manufacturing,
    categories: remote.categories.length ? remote.categories : local.categories,
    labels: remote.labels.length ? remote.labels : local.labels,
    palmOil: remote.palmOil || local.palmOil,
    source: "registre",
  };
}
