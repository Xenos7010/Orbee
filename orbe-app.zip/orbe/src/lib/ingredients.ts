import type { Additive, DietFlag, Ingredient } from "./types";

const RULES: [RegExp, string][] = [
  [/caffeine|cafeine|caféine/, "cafeine"],
  [/theobrom|cacao maigre|fat-reduced-cocoa|cocoa powder/, "theobromine"],
  [/beurre de cacao|cocoa butter|cocoa-butter/, "triglyceride"],
  [/pâte de cacao|pate de cacao|cocoa paste|cocoa mass|cocoa-paste/, "theobromine"],
  [/saccharose|\bsucre\b|\bsugar\b|azucar|azúcar/, "saccharose"],
  [/sirop de glucose|glucose/, "glucose"],
  [/fructose/, "fructose"],
  [/lactose|lait|milk|lactoserum|lactosérum|whey|poudre de lait/, "lactose"],
  [/lécithine|lecithine|lecithin|\be322\b/, "lecithine"],
  [/vanill/, "vanilline"],
  [/huile de palme|palm/, "triglyceride"],
  [/noisette|hazelnut/, "oleique"],
  [/huile|graisse|\boil\b|beurre|oleic|oléique/, "oleique"],
  [/dioxyde de carbone|carbonique|\be290\b|\bco2\b/, "co2"],
  [/phosphorique|phosphoric|\be338\b/, "phosphorique"],
  [/citrique|citric|\be330\b/, "citrique"],
  [/caramel|\be150\b/, "maltol"],
  [/chlorure de sodium|sodium chloride|\bsel\b/, "nacl"],
  [/bicarbonate|hydrogénocarbonate|hydrogenocarbonate/, "bicarbonate"],
  [/sulfate/, "sulfate"],
  [/silice|silica|silicium/, "silice"],
  [/calcium/, "calcium"],
  [/magnésium|magnesium/, "magnesium"],
  [/potassium/, "potassium"],
  [/chlorure|chloride/, "chlorure"],
  [/sodium/, "sodium"],
  [/amidon|semoule|blé|ble dur|wheat|farine|starch|penne|pâte/, "amidon"],
  [/fibre|cellulose/, "cellulose"],
  [/protéine|protein|gluten|caséine|casein/, "helix"],
  [/lycop|tomate|ketchup/, "lycopene"],
  [/eau gaz|carbonated|gazéif|gazeif/, "eau"],
  [/café|coffee/, "cafeine"],
  [/\beau\b|water|agua/, "eau"],
  [/arome|arôme|flavour|flavor/, "vanilline"],
];

const ID_FR: Record<string, string> = {
  "en:sugar": "Sucre",
  "en:palm-oil": "Huile de palme",
  "en:hazelnut": "Noisettes",
  "en:hazelnuts": "Noisettes",
  "en:water": "Eau",
  "en:carbonated-water": "Eau gazéifiée",
  "en:e150d": "Colorant caramel E150d",
  "en:e338": "Acide phosphorique",
  "en:natural-flavouring": "Arômes naturels",
  "en:cocoa-paste": "Pâte de cacao",
  "en:cocoa-butter": "Beurre de cacao",
  "en:vanilla": "Vanille",
  "en:vanillin": "Vanilline",
  "en:durum-wheat-semolina": "Semoule de blé dur",
  "en:skimmed-milk-powder": "Lait écrémé en poudre",
  "en:skim-milk-powder": "Lait écrémé en poudre",
  "en:whey-powder": "Lactosérum en poudre",
  "en:e322": "Lécithines",
  "en:e322i": "Lécithine",
  "en:fat-reduced-cocoa": "Cacao maigre",
  "en:cocoa": "Cacao",
  "en:salt": "Sel",
  "en:wheat": "Blé",
};

export function moleculeFor(name: string, id?: string | null): string {
  const hay = `${id ?? ""} ${name}`.toLowerCase();
  for (const [re, mol] of RULES) {
    if (re.test(hay)) return mol;
  }
  return "organique";
}

export function frenchName(text: string, id?: string | null): string {
  if (id && ID_FR[id]) return ID_FR[id];
  const bare = (id ?? "").replace(/^en:/, "");
  if (bare.startsWith("e") && /^e\d+/i.test(bare)) return `Additif ${bare.toUpperCase()}`;
  const clean = text.replace(/[_]+/g, " ").replace(/\s+/g, " ").trim();
  if (!clean) return "Ingrédient";
  return clean.charAt(0).toUpperCase() + clean.slice(1);
}

export function balancePercents(rows: { percent: number | null }[]): { percent: number; estimated: boolean }[] {
  const explicit = rows.map((r) => (r.percent != null && r.percent > 0 ? r.percent : null));
  const known = explicit.reduce<number>((s, n) => s + (n ?? 0), 0);
  const missingIdx = explicit.flatMap((n, i) => (n == null ? [i] : []));
  if (missingIdx.length === 0) {
    const s = known || 1;
    return explicit.map((n) => ({ percent: ((n ?? 0) / s) * 100, estimated: false }));
  }
  if (known === 0) {
    const w = rows.map((_, i) => Math.pow(0.62, i));
    const s = w.reduce((a, b) => a + b, 0);
    return w.map((x) => ({ percent: (x / s) * 100, estimated: true }));
  }
  if (known >= 99.5) {
    const reserve = Math.min(8, missingIdx.length * 1.5);
    const s = known || 1;
    const out = explicit.map((n) =>
      n == null
        ? { percent: 0, estimated: true }
        : { percent: (n / s) * (100 - reserve), estimated: false },
    );
    const share = reserve / missingIdx.length;
    for (const idx of missingIdx) out[idx] = { percent: share, estimated: true };
    return out;
  }
  const remain = Math.max(0, 100 - known);
  const w = missingIdx.map((_, i) => Math.pow(0.55, i));
  const s = w.reduce((a, b) => a + b, 0);
  const out = explicit.map((n) =>
    n == null ? { percent: 0, estimated: true } : { percent: n, estimated: false },
  );
  missingIdx.forEach((idx, i) => {
    out[idx] = { percent: remain * (w[i] / s), estimated: true };
  });
  return out;
}

export function roundShares(rows: { percent: number; estimated: boolean }[]): { percent: number; estimated: boolean }[] {
  const rounded = rows.map((r) => ({
    percent: Math.round(r.percent * 10) / 10,
    estimated: r.estimated,
  }));
  const drift = Math.round((100 - rounded.reduce((s, r) => s + r.percent, 0)) * 10) / 10;
  if (rounded.length && Math.abs(drift) >= 0.1 && Math.abs(drift) < 5) {
    const i = rounded.reduce((best, r, idx, arr) => (r.percent > arr[best].percent ? idx : best), 0);
    rounded[i] = { ...rounded[i], percent: Math.round((rounded[i].percent + drift) * 10) / 10 };
  }
  return rounded;
}

export type RawIngredient = {
  name: string;
  percent?: number | null;
  estimated?: boolean;
  moleculeId?: string;
  lens?: boolean;
  vegan?: DietFlag;
  vegetarian?: DietFlag;
  fromPalmOil?: boolean;
  allergen?: boolean;
  note?: string;
  offId?: string | null;
};

export function makeIngredients(rows: RawIngredient[], key: string): Ingredient[] {
  const balanced = roundShares(balancePercents(rows.map((r) => ({ percent: r.percent ?? null }))));
  return rows.map((r, i) => {
    const share = balanced[i] ?? { percent: 0, estimated: true };
    const declared = r.percent != null && r.percent > 0;
    return {
      id: `${key}-${i}`,
      name: r.name,
      percent: share.percent,
      percentEstimated: declared ? (r.estimated ?? false) : share.estimated,
      vegan: r.vegan ?? null,
      vegetarian: r.vegetarian ?? null,
      fromPalmOil: r.fromPalmOil ?? false,
      allergen: r.allergen ?? false,
      moleculeId: r.moleculeId ?? moleculeFor(r.name, r.offId),
      lens: r.lens ?? share.percent < 1.15,
      note: r.note ?? "",
    };
  });
}

const ADDITIVES: Record<string, Omit<Additive, "code">> = {
  e322: {
    name: "Lécithines",
    role: "Émulsifiant",
    note: "Phospholipides, souvent de soja, de tournesol ou d'œuf. Ils stabilisent un mélange d'eau et de gras.",
    watch: "faible",
  },
  e322i: {
    name: "Lécithine",
    role: "Émulsifiant",
    note: "Forme courante de la lécithine, très utilisée dans le chocolat et les pâtes à tartiner.",
    watch: "faible",
  },
  e150d: {
    name: "Caramel au sulfite d'ammonium",
    role: "Colorant",
    note: "Couleur brune des colas, obtenue en chauffant des sucres avec sulfites et ammonium.",
    watch: "discute",
  },
  e150a: {
    name: "Caramel ordinaire",
    role: "Colorant",
    note: "Sucres chauffés, sans réactif ammoniacal.",
    watch: "faible",
  },
  e338: {
    name: "Acide phosphorique",
    role: "Acidifiant",
    note: "Donne l'acidité nette du cola. Apporte aussi du phosphore.",
    watch: "modere",
  },
  e330: {
    name: "Acide citrique",
    role: "Acidifiant",
    note: "Acide des agrumes, très utilisé pour relever le goût et limiter l'oxydation.",
    watch: "faible",
  },
  e300: {
    name: "Acide ascorbique",
    role: "Antioxydant",
    note: "Vitamine C ajoutée pour protéger la couleur et le goût.",
    watch: "faible",
  },
  e202: {
    name: "Sorbate de potassium",
    role: "Conservateur",
    note: "Limite les levures et les moisissures dans les produits humides.",
    watch: "faible",
  },
  e211: {
    name: "Benzoate de sodium",
    role: "Conservateur",
    note: "Conservateur des boissons acides. Surveillé lorsqu'il coexiste avec la vitamine C.",
    watch: "modere",
  },
  e621: {
    name: "Glutamate de sodium",
    role: "Exhausteur",
    note: "Sel de l'acide glutamique, il renforce le goût salé-bouillon.",
    watch: "discute",
  },
  e471: {
    name: "Mono- et diglycérides",
    role: "Émulsifiant",
    note: "Fragments de matières grasses, fréquents dans les produits industriels.",
    watch: "faible",
  },
  e476: {
    name: "Polyricinoléate de polyglycérol",
    role: "Émulsifiant",
    note: "Utilisé dans le chocolat pour fluidifier la pâte. Souvent issu du ricin.",
    watch: "modere",
  },
  e500: {
    name: "Carbonates de sodium",
    role: "Régulateur",
    note: "Famille du bicarbonate. Sert à lever ou à ajuster l'acidité.",
    watch: "faible",
  },
  e440: {
    name: "Pectines",
    role: "Gélifiant",
    note: "Fibres de fruits, utilisées pour les confitures et les desserts.",
    watch: "faible",
  },
  e412: {
    name: "Gomme guar",
    role: "Épaississant",
    note: "Fibre de légumineuse, elle épaissit sans apporter de goût.",
    watch: "faible",
  },
  e951: {
    name: "Aspartame",
    role: "Édulcorant",
    note: "Édulcorant intense. À éviter en cas de phénylcétonurie, mention obligatoire.",
    watch: "discute",
  },
  e955: {
    name: "Sucralose",
    role: "Édulcorant",
    note: "Dérivé chloré du sucre, très sucrant, presque non calorique.",
    watch: "modere",
  },
  e250: {
    name: "Nitrite de sodium",
    role: "Conservateur",
    note: "Utilisé dans les charcuteries. Point de vigilance classique des produits carnés.",
    watch: "discute",
  },
  e129: {
    name: "Rouge allura",
    role: "Colorant",
    note: "Colorant azoïque. Peut être signalé pour l'attention des enfants.",
    watch: "discute",
  },
  e102: {
    name: "Tartrazine",
    role: "Colorant",
    note: "Jaune de synthèse, parfois associé à des réactions chez les personnes sensibles.",
    watch: "discute",
  },
  e133: {
    name: "Bleu brillant",
    role: "Colorant",
    note: "Colorant bleu de synthèse.",
    watch: "modere",
  },
  e160a: {
    name: "Caroténoïdes",
    role: "Colorant",
    note: "Pigments d'origine végétale, proches de la vitamine A.",
    watch: "faible",
  },
  e422: {
    name: "Glycérol",
    role: "Humectant",
    note: "Garde le moelleux. C'est aussi le squelette des triglycérides.",
    watch: "faible",
  },
};

export function describeAdditive(tag: string): Additive {
  const code = tag.replace(/^en:/, "").toLowerCase();
  const known = ADDITIVES[code];
  const pretty = code.toUpperCase();
  if (known) return { code: pretty, ...known };
  return {
    code: pretty,
    name: `Additif ${pretty}`,
    role: "Additif",
    note: "Référencé dans la liste. Le détail réglementaire dépend de la dose et du produit.",
    watch: null,
  };
}

const ALLERGEN_FR: Record<string, string> = {
  milk: "Lait",
  nuts: "Fruits à coque",
  soybeans: "Soja",
  gluten: "Gluten",
  eggs: "Œufs",
  fish: "Poisson",
  peanuts: "Arachides",
  crustaceans: "Crustacés",
  celery: "Céleri",
  mustard: "Moutarde",
  sesame: "Sésame",
  "sesame-seeds": "Sésame",
  lupin: "Lupin",
  molluscs: "Mollusques",
  sulphites: "Sulfites",
  "sulfur-dioxide-and-sulfites": "Sulfites",
  none: "",
};

export function translateAllergen(raw: string): string {
  const key = raw.trim().toLowerCase().replace(/^en:/, "").replace(/\s+/g, "-");
  if (!key || key === "none" || key === "aucun") return "";
  return ALLERGEN_FR[key] ?? raw.trim().replace(/^en:/, "").replace(/-/g, " ");
}

export function splitList(value: string | null | undefined): string[] {
  if (!value) return [];
  return value
    .split(/[,;]/)
    .map((s) => translateAllergen(s))
    .filter(Boolean)
    .filter((v, i, arr) => arr.indexOf(v) === i);
}

const LABELS: Record<string, string> = {
  "en:vegetarian": "Végétarien",
  "en:vegan": "Végétalien",
  "en:no-gluten": "Sans gluten",
  "en:organic": "Agriculture biologique",
  "fr:triman": "Triman",
  "en:green-dot": "Point vert",
  "en:made-in-france": "Fabriqué en France",
  "en:made-in-the-eu": "Fabriqué dans l'UE",
  "en:halal": "Halal",
  "en:carbon-footprint": "Empreinte carbone",
  "fr:tidy-man": "TidyMan",
  "en:eu-organic": "Bio européen",
};

export function translateLabel(tag: string): string | null {
  if (LABELS[tag]) return LABELS[tag];
  if (tag.startsWith("en:") || tag.startsWith("fr:")) {
    const words = tag.slice(3).replace(/-/g, " ");
    if (words.length < 3) return null;
    return words.charAt(0).toUpperCase() + words.slice(1);
  }
  return tag;
}

export function cleanCategory(tag: string): string | null {
  const raw = tag.replace(/^[a-z]{2}:/, "").replace(/-/g, " ").trim();
  if (!raw || raw.length < 3) return null;
  return raw.charAt(0).toUpperCase() + raw.slice(1);
}

export const NOVA_COPY: Record<number, { title: string; text: string }> = {
  1: {
    title: "Non transformé",
    text: "Aliment brut ou presque : fruit, eau, céréale, viande. Rien, ou presque, n'a été ajouté.",
  },
  2: {
    title: "Ingrédient culinaire",
    text: "Sucre, huile, sel, beurre. Sert à cuisiner, rarement à se nourrir seul.",
  },
  3: {
    title: "Transformé",
    text: "Produit reconnaissable, modifié par une recette : pain, fromage, conserve simple.",
  },
  4: {
    title: "Ultra-transformé",
    text: "Recette industrielle avec additifs, arômes ou procédés qu'on ne refait pas chez soi.",
  },
};

export const NUTRI_COPY: Record<string, string> = {
  a: "Le plus favorable sur le plan nutritionnel.",
  b: "Profil plutôt favorable.",
  c: "Profil intermédiaire.",
  d: "Profil peu favorable, à garder occasionnel.",
  e: "Le moins favorable : sucres, gras ou sel élevés.",
};

export const ECO_COPY: Record<string, string> = {
  a: "Impact environnemental estimé le plus bas.",
  b: "Impact plutôt contenu.",
  c: "Impact intermédiaire.",
  d: "Impact élevé.",
  e: "Impact estimé le plus lourd.",
};
