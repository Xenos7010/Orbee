export type ScoreLetter = "a" | "b" | "c" | "d" | "e";

export type DietFlag = "yes" | "no" | "maybe" | null;

export type Ingredient = {
  id: string;
  name: string;
  percent: number;
  percentEstimated: boolean;
  vegan: DietFlag;
  vegetarian: DietFlag;
  fromPalmOil: boolean;
  allergen: boolean;
  moleculeId: string;
  lens: boolean;
  note: string;
};

export type Additive = {
  code: string;
  name: string;
  role: string;
  note: string;
  watch: "faible" | "modere" | "discute" | null;
};

export type Nutriments = {
  energyKcal: number | null;
  energyKj: number | null;
  fat: number | null;
  saturatedFat: number | null;
  carbohydrates: number | null;
  sugars: number | null;
  fiber: number | null;
  proteins: number | null;
  salt: number | null;
};

export type PricePoint = {
  price: number;
  currency: string;
  store: string | null;
  city: string | null;
  date: string | null;
  indicative: boolean;
};

export type Product = {
  barcode: string;
  name: string;
  brand: string;
  quantity: string;
  genericName: string;
  image: string | null;
  categories: string[];
  labels: string[];
  origins: string;
  countries: string;
  packaging: string;
  manufacturing: string;
  ingredientsText: string;
  ingredients: Ingredient[];
  /** Richer 3D breakdown when the legal list is a single raw material. */
  matter: Ingredient[] | null;
  matterLabel: string | null;
  allergens: string[];
  traces: string[];
  additives: Additive[];
  nutriments: Nutriments;
  nutriscore: ScoreLetter | null;
  nova: number | null;
  ecoscore: ScoreLetter | null;
  servingSize: string | null;
  servingGrams: number | null;
  prices: PricePoint[];
  palmOil: boolean;
  source: "catalogue" | "registre";
};

export type SearchHit = {
  barcode: string;
  name: string;
  brand: string;
  quantity: string;
  image: string | null;
  nutriscore: ScoreLetter | null;
};

export type AtelierMode = "composition" | "structure" | "elements";
