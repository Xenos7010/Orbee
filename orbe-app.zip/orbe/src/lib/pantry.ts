export type HistoryItem = {
  barcode: string;
  name: string;
  brand: string;
  image: string | null;
  at: number;
};

export type PersonalPrice = { price: number; store: string; at: number };

const HISTORY = "orbe.history.v1";
const FAVS = "orbe.favorites.v1";
const PRICES = "orbe.prices.v1";
const SEEN = "orbe.intro.v1";

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* stockage plein ou bloqué : on ignore */
  }
}

export function readHistory(): HistoryItem[] {
  const items = read<HistoryItem[]>(HISTORY, []);
  return Array.isArray(items) ? items.slice(0, 30) : [];
}

export function rememberProduct(item: Omit<HistoryItem, "at">) {
  const next = [{ ...item, at: Date.now() }, ...readHistory().filter((h) => h.barcode !== item.barcode)].slice(0, 30);
  write(HISTORY, next);
  return next;
}

export function clearHistory() {
  write(HISTORY, []);
}

export function readFavorites(): HistoryItem[] {
  const items = read<HistoryItem[]>(FAVS, []);
  return Array.isArray(items) ? items : [];
}

export function isFavorite(barcode: string): boolean {
  return readFavorites().some((f) => f.barcode === barcode);
}

/** Ajoute ou retire un favori. Renvoie le nouvel état (true = favori). */
export function toggleFavorite(item: Omit<HistoryItem, "at">): boolean {
  const all = readFavorites();
  const exists = all.some((f) => f.barcode === item.barcode);
  write(FAVS, exists ? all.filter((f) => f.barcode !== item.barcode) : [{ ...item, at: Date.now() }, ...all]);
  return !exists;
}

export function readPrice(barcode: string): PersonalPrice | null {
  return read<Record<string, PersonalPrice>>(PRICES, {})[barcode] ?? null;
}

export function savePrice(barcode: string, price: PersonalPrice) {
  const all = read<Record<string, PersonalPrice>>(PRICES, {});
  all[barcode] = price;
  write(PRICES, all);
}

export function introSeen(): boolean {
  return read<boolean>(SEEN, false);
}

export function markIntroSeen() {
  write(SEEN, true);
}
