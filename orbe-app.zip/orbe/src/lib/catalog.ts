import { makeIngredients } from "./ingredients";
import type { Ingredient, Nutriments, Product } from "./types";

const emptyNutri = (): Nutriments => ({
  energyKcal: null,
  energyKj: null,
  fat: null,
  saturatedFat: null,
  carbohydrates: null,
  sugars: null,
  fiber: null,
  proteins: null,
  salt: null,
});

function product(partial: Omit<Product, "palmOil" | "ingredients" | "matter"> & {
  ingredients: Ingredient[];
  matter?: Ingredient[] | null;
}): Product {
  const matter = partial.matter ?? null;
  const palmOil =
    partial.ingredients.some((i) => i.fromPalmOil) || (matter?.some((i) => i.fromPalmOil) ?? false);
  return { ...partial, matter, palmOil };
}

const nutellaIngs = makeIngredients(
  [
    { name: "Sucre", percent: 51.2, moleculeId: "saccharose", note: "Premier ingrédient. Presque tout le sucre du Nutri-Score vient d'ici." },
    { name: "Huile de palme", percent: 18.3, fromPalmOil: true, moleculeId: "triglyceride", estimated: true, note: "Corps gras qui rend la pâte souple à température ambiante." },
    { name: "Noisettes", percent: 13, moleculeId: "oleique", note: "13 % annoncés sur le pot. L'acide oléique domine leur huile." },
    { name: "Cacao maigre", percent: 7.4, moleculeId: "theobromine", note: "Cacao dégraissé. La théobromine en est le marqueur amer." },
    { name: "Lait écrémé en poudre", percent: 6.6, moleculeId: "lactose", vegan: "no", vegetarian: "yes", allergen: true, note: "Apporte le lactose et les protéines du lait." },
    { name: "Lactosérum en poudre", percent: 1.9, moleculeId: "lactose", vegan: "no", vegetarian: "yes", allergen: true, estimated: true },
    { name: "Lécithines de soja", percent: 1.2, moleculeId: "lecithine", allergen: true, estimated: true, note: "Émulsifiant E322. Lie le gras et le reste de la pâte." },
    { name: "Vanilline", percent: 0.4, moleculeId: "vanilline", lens: true, estimated: true, note: "Arôme, en très petite quantité." },
  ],
  "nutella",
);

const cokeMatter = makeIngredients(
  [
    { name: "Eau", percent: 86.2, moleculeId: "eau", estimated: true },
    { name: "Saccharose", percent: 10.6, moleculeId: "saccharose", note: "Tout le sucre affiché aux 100 ml." },
    { name: "Dioxyde de carbone", percent: 2.4, moleculeId: "co2", estimated: true, note: "Gaz dissous, responsable des bulles." },
    { name: "Colorant caramel E150d", percent: 0.35, moleculeId: "maltol", lens: true, estimated: true, note: "Le maltol sert de repère aromatique. Le colorant réel est un mélange." },
    { name: "Acide phosphorique", percent: 0.35, moleculeId: "phosphorique", lens: true, estimated: true },
    { name: "Caféine", percent: 0.1, moleculeId: "cafeine", lens: true, estimated: true, note: "Environ 32 mg dans une canette de 33 cl." },
  ],
  "coke-matter",
);

const cokeIngs = makeIngredients(
  [
    { name: "Eau gazéifiée", percent: 86, moleculeId: "eau", estimated: true },
    { name: "Sucre", percent: 10.6, moleculeId: "saccharose" },
    { name: "Colorant : E150d", percent: 1.4, moleculeId: "maltol", estimated: true },
    { name: "Acide phosphorique", percent: 1.2, moleculeId: "phosphorique", estimated: true },
    { name: "Arômes naturels, dont caféine", percent: 0.8, moleculeId: "cafeine", lens: true, estimated: true },
  ],
  "coke",
);

const evianMatter = makeIngredients(
  [
    { name: "Eau", percent: 99.95, moleculeId: "eau", note: "La quasi-totalité du volume. Les minéraux sont des traces, grossies dans la loupe." },
    { name: "Hydrogénocarbonates", percent: 0.036, moleculeId: "bicarbonate", lens: true, note: "360 mg/L. Anion dominant du résidu sec." },
    { name: "Calcium", percent: 0.008, moleculeId: "calcium", lens: true, note: "80 mg/L." },
    { name: "Magnésium", percent: 0.0026, moleculeId: "magnesium", lens: true, note: "26 mg/L." },
    { name: "Silice", percent: 0.0015, moleculeId: "silice", lens: true, note: "15 mg/L." },
    { name: "Sulfates", percent: 0.0014, moleculeId: "sulfate", lens: true, note: "14 mg/L." },
    { name: "Chlorures", percent: 0.001, moleculeId: "chlorure", lens: true, note: "10 mg/L." },
    { name: "Sodium", percent: 0.00065, moleculeId: "sodium", lens: true, note: "6,5 mg/L." },
    { name: "Potassium", percent: 0.0001, moleculeId: "potassium", lens: true, note: "Environ 1 mg/L." },
  ],
  "evian-matter",
);

const pastaMatter = makeIngredients(
  [
    { name: "Amidon", percent: 71, moleculeId: "amidon", note: "Réserve du grain de blé dur." },
    { name: "Protéines", percent: 13, moleculeId: "helix", allergen: true, note: "Surtout du gluten. Le modèle montre le squelette d'une hélice, pas la gliadine entière." },
    { name: "Eau résiduelle", percent: 10.5, moleculeId: "eau", estimated: true },
    { name: "Fibres", percent: 3, moleculeId: "cellulose" },
    { name: "Lipides", percent: 2, moleculeId: "oleique", estimated: true, note: "Très peu de gras dans une semoule." },
    { name: "Sucres", percent: 0.5, moleculeId: "glucose", lens: true },
  ],
  "pasta-matter",
);

export const CATALOG: Product[] = [
  product({
    barcode: "3017620422003",
    name: "Nutella",
    brand: "Ferrero",
    quantity: "400 g",
    genericName: "Pâte à tartiner aux noisettes et au cacao",
    image: "https://images.openfoodfacts.org/images/products/301/762/042/2003/front_en.879.400.jpg",
    categories: ["Petit-déjeuners", "Pâtes à tartiner"],
    labels: ["Végétarien", "Sans gluten"],
    origins: "",
    countries: "France",
    packaging: "Pot en verre, opercule, couvercle",
    manufacturing: "",
    ingredientsText:
      "Sucre, huile de palme, noisettes 13 %, cacao maigre 7,4 %, lait écrémé en poudre 6,6 %, lactosérum en poudre, émulsifiants : lécithines de soja, vanilline.",
    ingredients: nutellaIngs,
    matter: null,
    matterLabel: null,
    allergens: ["Lait", "Fruits à coque", "Soja"],
    traces: [],
    additives: [
      {
        code: "E322",
        name: "Lécithines",
        role: "Émulsifiant",
        note: "Phospholipides de soja. Ils empêchent la pâte de trancher.",
        watch: "faible",
      },
    ],
    nutriments: {
      ...emptyNutri(),
      energyKcal: 539,
      energyKj: 2252,
      fat: 30.9,
      saturatedFat: 10.6,
      carbohydrates: 57.5,
      sugars: 56.3,
      fiber: 0,
      proteins: 6.3,
      salt: 0.107,
    },
    nutriscore: "e",
    nova: 4,
    ecoscore: null,
    servingSize: "15 g",
    servingGrams: 15,
    prices: [{ price: 4.29, currency: "EUR", store: "Grande surface", city: null, date: null, indicative: true }],
    source: "catalogue",
  }),
  product({
    barcode: "5449000000996",
    name: "Coca-Cola",
    brand: "Coca-Cola",
    quantity: "330 ml",
    genericName: "Soda au cola",
    image: "https://images.openfoodfacts.org/images/products/544/900/000/0996/front_en.1129.400.jpg",
    categories: ["Boissons", "Sodas"],
    labels: ["Fabriqué dans l'UE"],
    origins: "",
    countries: "France",
    packaging: "Canette ou bouteille, selon le lot",
    manufacturing: "",
    ingredientsText:
      "Eau gazéifiée, sucre, colorant : E150d, acidifiant : acide phosphorique, arômes naturels (extraits végétaux), dont caféine.",
    ingredients: cokeIngs,
    matter: cokeMatter,
    matterLabel: "Composition estimée du liquide",
    allergens: [],
    traces: [],
    additives: [
      {
        code: "E150D",
        name: "Caramel au sulfite d'ammonium",
        role: "Colorant",
        note: "Donne la couleur brune. Obtenu en chauffant des sucres avec sulfites et ammonium.",
        watch: "discute",
      },
      {
        code: "E338",
        name: "Acide phosphorique",
        role: "Acidifiant",
        note: "Acidité franche du cola, et un apport de phosphore.",
        watch: "modere",
      },
    ],
    nutriments: {
      ...emptyNutri(),
      energyKcal: 42,
      energyKj: 180,
      fat: 0,
      saturatedFat: 0,
      carbohydrates: 10.6,
      sugars: 10.6,
      fiber: 0,
      proteins: 0,
      salt: 0,
    },
    nutriscore: "e",
    nova: 4,
    ecoscore: null,
    servingSize: "330 ml",
    servingGrams: 330,
    prices: [{ price: 1.15, currency: "EUR", store: "Grande surface", city: null, date: null, indicative: true }],
    source: "catalogue",
  }),
  product({
    barcode: "3068320055008",
    name: "Eau minérale naturelle Evian",
    brand: "Evian",
    quantity: "50 cl",
    genericName: "Eau minérale naturelle",
    image: "https://images.openfoodfacts.org/images/products/306/832/005/5008/front_en.179.400.jpg",
    categories: ["Eaux", "Eaux minérales"],
    labels: ["Végétarien"],
    origins: "Évian-les-Bains, France",
    countries: "France",
    packaging: "Bouteille plastique",
    manufacturing: "France",
    ingredientsText: "Eau minérale naturelle. Résidu sec à 180 °C : environ 345 mg/L.",
    ingredients: makeIngredients([{ name: "Eau minérale naturelle", percent: 100, moleculeId: "eau" }], "evian"),
    matter: evianMatter,
    matterLabel: "Eau et minéraux dissous",
    allergens: [],
    traces: [],
    additives: [],
    nutriments: {
      ...emptyNutri(),
      energyKcal: 0,
      energyKj: 0,
      fat: 0,
      saturatedFat: 0,
      carbohydrates: 0,
      sugars: 0,
      fiber: 0,
      proteins: 0,
      salt: 0.002,
    },
    nutriscore: "a",
    nova: 1,
    ecoscore: null,
    servingSize: "250 ml",
    servingGrams: 250,
    prices: [{ price: 0.85, currency: "EUR", store: "Grande surface", city: null, date: null, indicative: true }],
    source: "catalogue",
  }),
  product({
    barcode: "8076802085738",
    name: "Penne Rigate n°73",
    brand: "Barilla",
    quantity: "500 g",
    genericName: "Pâtes de semoule de blé dur",
    image: "https://images.openfoodfacts.org/images/products/807/680/208/5738/front_en.3506.400.jpg",
    categories: ["Pâtes alimentaires", "Céréales"],
    labels: ["Végétarien"],
    origins: "Italie",
    countries: "France",
    packaging: "Étui carton",
    manufacturing: "Italie",
    ingredientsText: "Semoule de blé dur. Peut contenir des traces de soja et de moutarde.",
    ingredients: makeIngredients(
      [{ name: "Semoule de blé dur", percent: 100, moleculeId: "amidon", allergen: true }],
      "barilla",
    ),
    matter: pastaMatter,
    matterLabel: "Composition estimée de la semoule",
    allergens: ["Gluten"],
    traces: ["Soja", "Œufs"],
    additives: [],
    nutriments: {
      ...emptyNutri(),
      energyKcal: 359,
      energyKj: 1521,
      fat: 2,
      saturatedFat: 0.5,
      carbohydrates: 71,
      sugars: 3.5,
      fiber: 3,
      proteins: 13,
      salt: 0.013,
    },
    nutriscore: "a",
    nova: 1,
    ecoscore: "b",
    servingSize: "80 g",
    servingGrams: 80,
    prices: [{ price: 1.69, currency: "EUR", store: "Grande surface", city: null, date: null, indicative: true }],
    source: "catalogue",
  }),
  product({
    barcode: "3046920028004",
    name: "Excellence 70 % cacao",
    brand: "Lindt",
    quantity: "100 g",
    genericName: "Chocolat noir extra-fin",
    image: "https://images.openfoodfacts.org/images/products/304/692/002/8004/front_en.435.400.jpg",
    categories: ["Chocolats", "Chocolats noirs"],
    labels: ["Végétarien", "Végétalien"],
    origins: "",
    countries: "France",
    packaging: "Tablette, étui carton",
    manufacturing: "France",
    ingredientsText: "Pâte de cacao, sucre, beurre de cacao, vanille.",
    ingredients: makeIngredients(
      [
        { name: "Pâte de cacao", percent: 45, moleculeId: "theobromine", estimated: true, note: "Cacao broyé, gras compris. La théobromine représente l'amertume, pas toute la pâte." },
        { name: "Sucre", percent: 29, moleculeId: "saccharose", estimated: true },
        { name: "Beurre de cacao", percent: 25, moleculeId: "triglyceride", estimated: true, note: "Matière grasse du cacao. Avec la pâte, on atteint les 70 % de cacao." },
        { name: "Vanille", percent: 1, moleculeId: "vanilline", lens: true, estimated: true },
      ],
      "lindt",
    ),
    matter: null,
    matterLabel: null,
    allergens: [],
    traces: ["Lait", "Fruits à coque", "Sésame", "Soja"],
    additives: [],
    nutriments: {
      ...emptyNutri(),
      energyKcal: 566,
      energyKj: 2371,
      fat: 41,
      saturatedFat: 24,
      carbohydrates: 35,
      sugars: 30,
      fiber: 12,
      proteins: 9.5,
      salt: 0.02,
    },
    nutriscore: "e",
    nova: 3,
    ecoscore: "e",
    servingSize: "12 g",
    servingGrams: 12,
    prices: [{ price: 2.79, currency: "EUR", store: "Grande surface", city: null, date: null, indicative: true }],
    source: "catalogue",
  }),
];

const BY_CODE = new Map(CATALOG.map((p) => [p.barcode, p]));

export function catalogProduct(barcode: string): Product | null {
  return BY_CODE.get(barcode) ?? null;
}

export function searchCatalog(q: string): Product[] {
  const n = q.trim().toLowerCase();
  if (n.length < 2) return [];
  return CATALOG.filter((p) => `${p.name} ${p.brand} ${p.barcode} ${p.genericName}`.toLowerCase().includes(n));
}
