import { parseOffProduct, parsePrices, parseSearch } from "./parse-off";
import type { PricePoint, Product, SearchHit } from "./types";

const FIELDS = [
  "product_name", "product_name_fr", "generic_name", "generic_name_fr", "brands", "quantity",
  "nutriscore_grade", "nova_group", "ecoscore_grade", "ingredients_text_fr", "ingredients_text",
  "allergens", "traces", "additives_tags", "labels_tags", "categories_tags_fr", "origins",
  "countries", "packaging_text_fr", "manufacturing_places", "serving_size", "nutriments",
  "ingredients", "image_front_url",
].join(",");

async function getJson(url: string, ms = 9000): Promise<unknown | null> {
  const ctrl = new AbortController();
  const timer = window.setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, { headers: { Accept: "application/json" }, signal: ctrl.signal });
    if (res.status === 404) return null;
    if (!res.ok) throw new Error(`Le service a répondu ${res.status}.`);
    return await res.json();
  } finally {
    window.clearTimeout(timer);
  }
}

export type ProductResult =
  | { ok: true; product: Product; prices: PricePoint[] }
  | { ok: false; reason: "notfound" | "offline" | "incomplete"; message: string };

export async function fetchProduct(barcode: string): Promise<ProductResult> {
  try {
    const [body, priceBody] = await Promise.all([
      getJson(`https://world.openfoodfacts.org/api/v2/product/${barcode}.json?fields=${FIELDS}`),
      getJson(`https://prices.openfoodfacts.org/api/v1/prices?product_code=${barcode}&size=8`).catch(() => null),
    ]);
    const raw = (body as { product?: unknown; status?: number } | null)?.product;
    if (!raw || (body as { status?: number }).status === 0) {
      return { ok: false, reason: "notfound", message: "Ce code-barres n'est pas encore dans la base Open Food Facts." };
    }
    const product = parseOffProduct(barcode, raw as never);
    if (!product) {
      return { ok: false, reason: "incomplete", message: "La fiche existe mais elle est trop incomplète pour être affichée." };
    }
    const prices = priceBody ? parsePrices(priceBody) : [];
    product.prices = prices;
    return { ok: true, product, prices };
  } catch {
    return { ok: false, reason: "offline", message: "Impossible de joindre Open Food Facts. Vérifie ta connexion internet." };
  }
}

export async function searchProducts(q: string): Promise<SearchHit[]> {
  const url =
    "https://world.openfoodfacts.org/cgi/search.pl?search_terms=" +
    encodeURIComponent(q) +
    "&search_simple=1&action=process&json=1&page_size=8&fields=code,product_name,product_name_fr,brands,quantity,image_front_small_url,nutriscore_grade";
  const body = await getJson(url);
  return body ? parseSearch(body) : [];
}
