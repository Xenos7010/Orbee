import { useState } from "react";
import { IconChevron, IconTrash } from "../components/icons";
import { SafeImg } from "../components/ui";
import { GLOSSARY } from "../data/glossary";
import { clearHistory, readFavorites, readHistory, type HistoryItem } from "../lib/pantry";
import { href } from "../router";

function List({ items }: { items: HistoryItem[] }) {
  return (
    <ul className="list card">
      {items.map((h) => (
        <li key={h.barcode}>
          <a className="row" href={href(`/produit/${h.barcode}`)}>
            <span className="thumb"><SafeImg src={h.image} alt="" letter={h.name} /></span>
            <span className="grow"><strong>{h.name}</strong><small>{h.brand}</small></span>
            <IconChevron className="chev" />
          </a>
        </li>
      ))}
    </ul>
  );
}

export function MePage() {
  const [favs] = useState(readFavorites);
  const [history, setHistory] = useState(readHistory);
  const [open, setOpen] = useState<string | null>(null);

  return (
    <div className="page">
      <header className="page-head">
        <span className="eyebrow">Mon espace</span>
        <h1>Favoris et historique</h1>
      </header>

      <section>
        <div className="section-title"><h2>Favoris</h2></div>
        {favs.length ? <List items={favs} /> : <p className="muted card pad">Touche le cœur sur une fiche produit pour la retrouver ici.</p>}
      </section>

      <section>
        <div className="section-title">
          <h2>Historique</h2>
          {history.length > 0 && (
            <button className="btn ghost small" onClick={() => { clearHistory(); setHistory([]); }}><IconTrash /> Vider</button>
          )}
        </div>
        {history.length ? <List items={history} /> : <p className="muted card pad">Les produits que tu consultes apparaîtront ici.</p>}
      </section>

      <section>
        <div className="section-title"><h2>Mini-glossaire</h2></div>
        <p className="muted">Les mots utiles pour tout comprendre. Touche un mot pour lire sa définition.</p>
        <ul className="glossary card">
          {GLOSSARY.map((g) => (
            <li key={g.term}>
              <button aria-expanded={open === g.term} onClick={() => setOpen(open === g.term ? null : g.term)}>
                <span>{g.term}</span>
                <IconChevron className={`chev ${open === g.term ? "turn" : ""}`} />
              </button>
              {open === g.term && <p>{g.def}</p>}
            </li>
          ))}
        </ul>
      </section>

      <section className="about card pad">
        <h3>À propos</h3>
        <p className="muted small">
          ORBE utilise la base collaborative Open Food Facts pour les produits et les prix. Les modèles de molécules sont
          pédagogiques : certains sont simplifiés et signalés comme tels. Cette appli ne remplace pas l'avis d'un professionnel de santé.
        </p>
      </section>
    </div>
  );
}
