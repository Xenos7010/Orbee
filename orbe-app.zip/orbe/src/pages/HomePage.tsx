import { useEffect, useRef, useState, type FormEvent } from "react";
import { Scanner } from "../components/Scanner";
import { IconAtom, IconChevron, IconGrid, IconScan, IconSearch, IconX } from "../components/icons";
import { SafeImg, ScoreBadge, Spinner } from "../components/ui";
import { searchProducts } from "../lib/api";
import { CATALOG, searchCatalog } from "../lib/catalog";
import { introSeen, markIntroSeen, readHistory, type HistoryItem } from "../lib/pantry";
import type { SearchHit } from "../lib/types";
import { go, href } from "../router";

function ProductRow({ code, name, sub, image, score }: { code: string; name: string; sub: string; image: string | null; score?: SearchHit["nutriscore"] }) {
  return (
    <a className="row" href={href(`/produit/${code}`)}>
      <span className="thumb"><SafeImg src={image} alt="" letter={name} /></span>
      <span className="grow">
        <strong>{name}</strong>
        <small>{sub}</small>
      </span>
      {score ? <ScoreBadge letter={score} size="sm" /> : null}
      <IconChevron className="chev" />
    </a>
  );
}

export function HomePage() {
  const [scanning, setScanning] = useState(false);
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [intro, setIntro] = useState(false);
  const seq = useRef(0);

  useEffect(() => {
    setHistory(readHistory());
    setIntro(!introSeen());
  }, []);

  useEffect(() => {
    const text = query.trim();
    setError(null);
    if (/^\d{8,14}$/.test(text)) {
      setHits([]);
      return;
    }
    if (text.length < 2) {
      setHits([]);
      setBusy(false);
      return;
    }
    const local: SearchHit[] = searchCatalog(text).map((p) => ({
      barcode: p.barcode, name: p.name, brand: p.brand, quantity: p.quantity, image: p.image, nutriscore: p.nutriscore,
    }));
    setHits(local);
    setBusy(true);
    const id = ++seq.current;
    const timer = window.setTimeout(() => {
      searchProducts(text)
        .then((remote) => {
          if (id !== seq.current) return;
          const seen = new Set(local.map((h) => h.barcode));
          setHits([...local, ...remote.filter((h) => !seen.has(h.barcode))].slice(0, 10));
        })
        .catch(() => id === seq.current && setError("Recherche en ligne indisponible. Les exemples ci-dessous restent accessibles."))
        .finally(() => id === seq.current && setBusy(false));
    }, 350);
    return () => window.clearTimeout(timer);
  }, [query]);

  function submit(e: FormEvent) {
    e.preventDefault();
    const digits = query.replace(/\D/g, "");
    if (/^\d{8,14}$/.test(digits)) go(`/produit/${digits}`);
  }

  function openCode(code: string) {
    setScanning(false);
    go(`/produit/${code}`);
  }

  const isCode = /^\d{8,14}$/.test(query.replace(/\s/g, ""));

  return (
    <div className="page">
      <header className="brand">
        <span className="logo"><IconAtom /></span>
        <div>
          <b>ORBE</b>
          <small>Du code-barres à la molécule</small>
        </div>
      </header>

      <section className="hero">
        <h1>Que contient<br />ce que tu manges ?</h1>
        <p>Scanne un produit : on t'explique sa qualité, ses ingrédients et les molécules qui le composent.</p>
        <button className="btn primary big" onClick={() => setScanning(true)}>
          <IconScan /> Scanner un produit
        </button>
      </section>

      <form className="search" onSubmit={submit}>
        <IconSearch />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Nom du produit ou code-barres"
          aria-label="Chercher un produit"
          autoComplete="off"
          enterKeyHint="search"
        />
        {query && (
          <button type="button" className="icon-btn" aria-label="Effacer" onClick={() => setQuery("")}><IconX /></button>
        )}
      </form>

      {isCode && (
        <button className="btn primary full" onClick={() => go(`/produit/${query.replace(/\D/g, "")}`)}>
          Ouvrir le produit {query.replace(/\D/g, "")}
        </button>
      )}
      {busy && <Spinner label="Recherche…" />}
      {error && <p className="note">{error}</p>}
      {hits.length > 0 && (
        <ul className="list card">
          {hits.map((h) => (
            <li key={h.barcode}>
              <ProductRow code={h.barcode} name={h.name} sub={[h.brand, h.quantity].filter(Boolean).join(" · ")} image={h.image} score={h.nutriscore} />
            </li>
          ))}
        </ul>
      )}

      {intro && (
        <section className="card intro">
          <div className="intro-head">
            <h2>Comment ça marche ?</h2>
            <button className="icon-btn" aria-label="Masquer" onClick={() => { markIntroSeen(); setIntro(false); }}><IconX /></button>
          </div>
          <ol>
            <li><b>1</b><span><strong>Scanne</strong> le code-barres d'un produit (ou cherche-le par son nom).</span></li>
            <li><b>2</b><span><strong>Lis</strong> les notes en clair : qualité nutritionnelle, transformation, additifs.</span></li>
            <li><b>3</b><span><strong>Explore</strong> les molécules de ses ingrédients en 3D et découvre les éléments du tableau périodique.</span></li>
          </ol>
        </section>
      )}

      <section>
        <div className="section-title"><h2>Essaie avec un exemple</h2></div>
        <div className="examples">
          {CATALOG.map((p) => (
            <a key={p.barcode} className="example" href={href(`/produit/${p.barcode}`)}>
              <span className="thumb big"><SafeImg src={p.image} alt="" letter={p.name} /></span>
              <strong>{p.name}</strong>
              <small>{p.brand}</small>
            </a>
          ))}
        </div>
      </section>

      <a className="promo" href={href("/tableau")}>
        <span className="promo-icon"><IconGrid /></span>
        <span className="grow">
          <strong>Tableau périodique interactif</strong>
          <small>118 éléments, électrons et quiz</small>
        </span>
        <IconChevron className="chev" />
      </a>

      {history.length > 0 && (
        <section>
          <div className="section-title"><h2>Consultés récemment</h2></div>
          <ul className="list card">
            {history.slice(0, 5).map((h) => (
              <li key={h.barcode}><ProductRow code={h.barcode} name={h.name} sub={h.brand} image={h.image} /></li>
            ))}
          </ul>
        </section>
      )}

      {scanning && <Scanner onCode={openCode} onClose={() => setScanning(false)} />}
    </div>
  );
}
