import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { MoleculeDetail } from "../components/MoleculeDetail";
import { IconBack, IconHeart } from "../components/icons";
import { Empty, SafeImg, ScoreBadge, Seg, SectionTitle, Spinner, prettyFormula } from "../components/ui";
import { SCORE_TEXT } from "../data/glossary";
import { fetchProduct } from "../lib/api";
import { catalogProduct } from "../lib/catalog";
import { getMolecule } from "../lib/molecules";
import { formatAmount, formatPrice, median, NUTRIENT_ROWS, placeLine, scaleNutriment } from "../lib/nutrition";
import { isFavorite, readPrice, rememberProduct, savePrice, toggleFavorite } from "../lib/pantry";
import { mergeProduct } from "../lib/parse-off";
import type { Ingredient, Product } from "../lib/types";
import { back, go } from "../router";

type Tab = "resume" | "ingredients" | "nutrition" | "molecules" | "details";
type Tone = "good" | "ok" | "warn" | "bad";

const TABS: { value: Tab; label: string }[] = [
  { value: "resume", label: "Résumé" },
  { value: "ingredients", label: "Ingrédients" },
  { value: "nutrition", label: "Nutrition" },
  { value: "molecules", label: "Molécules" },
  { value: "details", label: "Infos" },
];

const fr = (n: number, d = 1) => new Intl.NumberFormat("fr-FR", { maximumFractionDigits: d }).format(n);

type Light = { key: "fat" | "saturatedFat" | "sugars" | "salt"; label: string; low: number; high: number };
const LIGHTS: Light[] = [
  { key: "fat", label: "Matières grasses", low: 3, high: 17.5 },
  { key: "saturatedFat", label: "Graisses saturées", low: 1.5, high: 5 },
  { key: "sugars", label: "Sucres", low: 5, high: 22.5 },
  { key: "salt", label: "Sel", low: 0.3, high: 1.5 },
];

function level(v: number, l: Light): "low" | "mid" | "high" {
  return v <= l.low ? "low" : v > l.high ? "high" : "mid";
}
const LEVEL_TEXT = { low: "Faible", mid: "Modéré", high: "Élevé" } as const;

function insights(p: Product): { tone: Tone; text: string }[] {
  const out: { tone: Tone; text: string }[] = [];
  const n = p.nutriments;
  if (n.sugars != null) {
    if (n.sugars > 22.5) out.push({ tone: "bad", text: `Très sucré : ${fr(n.sugars)} g de sucres pour 100 g, soit environ ${Math.round(n.sugars / 5)} morceaux de 5 g.` });
    else if (n.sugars <= 5) out.push({ tone: "good", text: "Peu de sucres ajoutés ou naturels." });
  }
  if (n.salt != null) {
    if (n.salt > 1.5) out.push({ tone: "bad", text: `Riche en sel : ${fr(n.salt, 2)} g pour 100 g.` });
    else if (n.salt <= 0.3) out.push({ tone: "good", text: "Faible teneur en sel." });
  }
  if (n.saturatedFat != null && n.saturatedFat > 5) out.push({ tone: "warn", text: `Beaucoup de graisses saturées : ${fr(n.saturatedFat)} g pour 100 g.` });
  if (n.fiber != null && n.fiber >= 6) out.push({ tone: "good", text: `Riche en fibres (${fr(n.fiber)} g pour 100 g).` });
  if (n.proteins != null && n.proteins >= 12) out.push({ tone: "good", text: `Bonne source de protéines (${fr(n.proteins)} g pour 100 g).` });
  if (p.palmOil) out.push({ tone: "warn", text: "Contient de l'huile de palme." });
  if (p.nova === 4) out.push({ tone: "warn", text: "Aliment ultra-transformé : recette industrielle avec additifs." });
  if (p.additives.length > 0) out.push({ tone: p.additives.length > 4 ? "warn" : "ok", text: `${p.additives.length} additif${p.additives.length > 1 ? "s" : ""} déclaré${p.additives.length > 1 ? "s" : ""}.` });
  if (p.allergens.length > 0) out.push({ tone: "warn", text: `Allergènes : ${p.allergens.join(", ")}.` });
  if (!out.length) out.push({ tone: "ok", text: "Pas assez de données pour un verdict détaillé sur ce produit." });
  return out;
}

export function ProductPage({ code }: { code: string }) {
  const valid = /^\d{8,14}$/.test(code);
  const local = useMemo(() => catalogProduct(code), [code]);
  const [remote, setRemote] = useState<Product | null>(null);
  const [phase, setPhase] = useState<"loading" | "ready" | "error">(local ? "ready" : "loading");
  const [problem, setProblem] = useState<{ reason: string; message: string } | null>(null);
  const [tick, setTick] = useState(0);
  const product = useMemo(() => mergeProduct(local, remote), [local, remote]);

  useEffect(() => {
    window.scrollTo(0, 0);
    setRemote(null);
    setProblem(null);
    if (!valid) return;
    let live = true;
    setPhase(local ? "ready" : "loading");
    fetchProduct(code).then((res) => {
      if (!live) return;
      if (res.ok) {
        setRemote(res.product);
        setPhase("ready");
      } else {
        setProblem({ reason: res.reason, message: res.message });
        if (!local) setPhase("error");
      }
    });
    return () => {
      live = false;
    };
  }, [code, valid, local, tick]);

  useEffect(() => {
    if (product) rememberProduct({ barcode: product.barcode, name: product.name, brand: product.brand, image: product.image });
  }, [product]);

  if (!valid) {
    return <Shell><Empty title="Code illisible" text="Un code-barres compte entre 8 et 14 chiffres." action={<button className="btn primary" onClick={() => go("/")}>Retour à l'accueil</button>} /></Shell>;
  }
  if (!product && phase === "loading") return <Shell><Spinner label="Recherche du produit…" /></Shell>;
  if (!product) {
    const offline = problem?.reason === "offline";
    return (
      <Shell>
        <Empty
          title={offline ? "Pas de connexion" : "Produit introuvable"}
          text={problem?.message ?? "Ce code ne figure pas dans la base."}
          action={
            <div className="row-actions">
              {offline && <button className="btn primary" onClick={() => setTick((t) => t + 1)}>Réessayer</button>}
              <button className="btn ghost" onClick={() => go("/")}>Autre produit</button>
            </div>
          }
        />
        {!offline && <p className="muted small center">Tu peux aider la communauté en ajoutant ce produit sur openfoodfacts.org.</p>}
      </Shell>
    );
  }
  return <Shell product={product}><Dossier product={product} offlineNote={problem?.reason === "offline" && !remote} /></Shell>;
}

function Shell({ children, product }: { children: ReactNode; product?: Product }) {
  const [fav, setFav] = useState(false);
  useEffect(() => { if (product) setFav(isFavorite(product.barcode)); }, [product]);
  return (
    <div className="page product">
      <div className="topbar">
        <button className="icon-btn" onClick={() => back("/")} aria-label="Retour"><IconBack /></button>
        {product && (
          <button
            className={`icon-btn ${fav ? "fav" : ""}`}
            aria-pressed={fav}
            aria-label={fav ? "Retirer des favoris" : "Ajouter aux favoris"}
            onClick={() => setFav(toggleFavorite({ barcode: product.barcode, name: product.name, brand: product.brand, image: product.image }))}
          >
            <IconHeart filled={fav} />
          </button>
        )}
      </div>
      {children}
    </div>
  );
}

function Dossier({ product, offlineNote }: { product: Product; offlineNote: boolean }) {
  const [tab, setTab] = useState<Tab>("resume");
  const [molId, setMolId] = useState<string | null>(null);

  useEffect(() => { setTab("resume"); setMolId(null); }, [product.barcode]);

  function openMolecule(id: string) {
    setMolId(id);
    setTab("molecules");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  return (
    <>
      <section className="p-hero">
        <div className="p-img"><SafeImg src={product.image} alt={product.name} letter={product.name} /></div>
        <div className="p-meta">
          <span className="eyebrow">{product.brand || "Marque inconnue"}</span>
          <h1>{product.name}</h1>
          <p className="muted small">{[product.quantity, product.genericName].filter(Boolean).join(" · ")}</p>
          <div className="scores">
            <ScoreBadge letter={product.nutriscore} />
            <ScoreBadge letter={product.nova} kind="nova" />
            <ScoreBadge letter={product.ecoscore} kind="eco" />
          </div>
        </div>
      </section>

      {offlineNote && <p className="note">Mode hors ligne : données de démonstration enregistrées dans l'appli.</p>}

      <div className="tabs-sticky">
        <Seg value={tab} onChange={setTab} options={TABS} label="Sections du produit" />
      </div>

      {tab === "resume" && <Resume product={product} />}
      {tab === "ingredients" && <Ingredients product={product} onMolecule={openMolecule} />}
      {tab === "nutrition" && <Nutrition product={product} />}
      {tab === "molecules" && <Molecules product={product} id={molId} onPick={setMolId} />}
      {tab === "details" && <Details product={product} />}
    </>
  );
}

function Resume({ product }: { product: Product }) {
  const list = insights(product);
  const rows: { kind: "nutri" | "nova" | "eco"; title: string; letter: string | null }[] = [
    { kind: "nutri", title: "Nutri-Score", letter: product.nutriscore },
    { kind: "nova", title: "NOVA · transformation", letter: product.nova ? String(product.nova) : null },
    { kind: "eco", title: "Éco-Score", letter: product.ecoscore },
  ];
  const n = product.nutriments;
  return (
    <div className="stack">
      <section className="card">
        <SectionTitle eyebrow="En un coup d'œil">Le verdict en clair</SectionTitle>
        <ul className="insights">
          {list.map((i, k) => (
            <li key={k} className={`tone-${i.tone}`}><span className="tone-dot" />{i.text}</li>
          ))}
        </ul>
      </section>

      <section className="card">
        <SectionTitle eyebrow="Les notes">Que veulent-elles dire ?</SectionTitle>
        <ul className="score-list">
          {rows.map((r) => {
            const info = r.letter ? SCORE_TEXT[r.kind][r.letter.toLowerCase()] : null;
            return (
              <li key={r.kind}>
                <ScoreBadge letter={r.letter as never} kind={r.kind} />
                <div>
                  <strong>{r.title}{info ? ` · ${info.title}` : ""}</strong>
                  <p className="muted small">{info ? info.text : "Pas de note disponible pour ce produit."}</p>
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      <section className="card">
        <SectionTitle eyebrow="Pour 100 g">Les repères essentiels</SectionTitle>
        <div className="lights">
          {LIGHTS.map((l) => {
            const v = n[l.key];
            if (v == null) return (
              <div key={l.key} className="light"><span className="light-dot none" /><div><small>{l.label}</small><strong>—</strong></div></div>
            );
            const lv = level(v, l);
            return (
              <div key={l.key} className="light">
                <span className={`light-dot ${lv}`} />
                <div>
                  <small>{l.label}</small>
                  <strong>{fr(v, 2)} g</strong>
                  <em>{LEVEL_TEXT[lv]}</em>
                </div>
              </div>
            );
          })}
        </div>
        <p className="muted small">Repères inspirés des feux tricolores britanniques. Utiles pour comparer, pas pour diagnostiquer.</p>
      </section>
    </div>
  );
}

function IngredientRow({ item, max, onMolecule }: { item: Ingredient; max: number; onMolecule: (id: string) => void }) {
  const mol = getMolecule(item.moleculeId);
  const known = item.moleculeId !== "organique";
  return (
    <li className="ing">
      <div className="ing-top">
        <strong>{item.name}</strong>
        <span className="muted small">{item.percentEstimated ? "≈ " : ""}{fr(item.percent)} %</span>
      </div>
      <div className="bar"><span style={{ width: `${Math.max(2, (item.percent / max) * 100)}%` }} /></div>
      <div className="ing-tags">
        {item.allergen && <span className="tag warn">Allergène</span>}
        {item.fromPalmOil && <span className="tag warn">Huile de palme</span>}
        {item.vegan === "no" && <span className="tag">Non végétalien</span>}
        {known && (
          <button className="tag link" onClick={() => onMolecule(item.moleculeId)}>
            {mol.name} · {prettyFormula(mol.formula)} ›
          </button>
        )}
      </div>
      {item.note && <p className="muted small">{item.note}</p>}
    </li>
  );
}

function Ingredients({ product, onMolecule }: { product: Product; onMolecule: (id: string) => void }) {
  const [layer, setLayer] = useState<"matiere" | "liste">(product.matter ? "matiere" : "liste");
  const items = layer === "matiere" && product.matter ? product.matter : product.ingredients;
  const max = Math.max(...items.map((i) => i.percent), 0.01);
  return (
    <div className="stack">
      <section className="card">
        <SectionTitle eyebrow="Du plus au moins présent">Ingrédients</SectionTitle>
        {product.matter && (
          <Seg value={layer} onChange={setLayer} label="Type de liste" options={[{ value: "matiere", label: product.matterLabel ?? "Composition réelle" }, { value: "liste", label: "Liste officielle" }]} />
        )}
        {items.length ? (
          <ul className="ing-list">{items.map((i) => <IngredientRow key={i.id} item={i} max={max} onMolecule={onMolecule} />)}</ul>
        ) : (
          <p className="muted">La liste des ingrédients n'est pas renseignée pour ce produit.</p>
        )}
        <p className="muted small">Les ingrédients sont classés par quantité décroissante. Le signe ≈ indique une part estimée quand elle n'est pas écrite sur l'emballage.</p>
      </section>

      {product.additives.length > 0 && (
        <section className="card">
          <SectionTitle eyebrow="Les codes E">Additifs</SectionTitle>
          <ul className="additives">
            {product.additives.map((a) => (
              <li key={a.code}>
                <div className="ing-top"><strong>{a.code.toUpperCase()} · {a.name}</strong>{a.watch && <span className={`tag ${a.watch === "faible" ? "" : "warn"}`}>{a.watch === "faible" ? "Veille faible" : a.watch === "modere" ? "À modérer" : "Discuté"}</span>}</div>
                <p className="muted small">{a.role}{a.note ? ` — ${a.note}` : ""}</p>
              </li>
            ))}
          </ul>
        </section>
      )}

      {product.ingredientsText && (
        <section className="card">
          <SectionTitle eyebrow="Tel qu'écrit sur l'emballage">Texte d'origine</SectionTitle>
          <p className="muted">{product.ingredientsText}</p>
        </section>
      )}
    </div>
  );
}

function Nutrition({ product }: { product: Product }) {
  const [basis, setBasis] = useState<"100" | "portion">("100");
  const grams = basis === "portion" && product.servingGrams ? product.servingGrams : 100;
  return (
    <section className="card">
      <SectionTitle eyebrow="Valeurs nutritionnelles">Pour {grams === 100 ? "100 g" : product.servingSize ?? "la portion"}</SectionTitle>
      {product.servingGrams ? (
        <Seg value={basis} onChange={setBasis} label="Base de calcul" options={[{ value: "100", label: "Pour 100 g" }, { value: "portion", label: `Portion (${product.servingSize})` }]} />
      ) : null}
      <ul className="nutri">
        {NUTRIENT_ROWS.map((row) => {
          const v = scaleNutriment(product.nutriments[row.key], grams);
          const share = v == null ? 0 : Math.min(100, (v / row.ri) * 100);
          return (
            <li key={row.key} className={row.indent ? "indent" : ""}>
              <div className="ing-top"><span>{row.label}</span><strong>{formatAmount(v, row.unit)}</strong></div>
              <div className="bar thin"><span style={{ width: `${share}%` }} /></div>
              <small className="muted">{v == null ? "Non renseigné" : `${Math.round(share)} % des repères journaliers`}</small>
            </li>
          );
        })}
      </ul>
      <p className="muted small">Les repères journaliers sont ceux d'un adulte (2 000 kcal par jour). Ils servent de point de comparaison.</p>
    </section>
  );
}

function Molecules({ product, id, onPick }: { product: Product; id: string | null; onPick: (id: string) => void }) {
  const groups = useMemo(() => {
    const map = new Map<string, string[]>();
    for (const item of [...(product.matter ?? []), ...product.ingredients]) {
      if (item.moleculeId === "organique") continue;
      const arr = map.get(item.moleculeId) ?? [];
      if (!arr.includes(item.name)) arr.push(item.name);
      map.set(item.moleculeId, arr);
    }
    return [...map.entries()].map(([mid, names]) => ({ id: mid, names }));
  }, [product]);

  if (!groups.length) {
    return (
      <section className="card">
        <Empty title="Aucune molécule identifiée" text="Les ingrédients de ce produit ne correspondent à aucune molécule de notre bibliothèque pour l'instant." action={<button className="btn ghost" onClick={() => go("/molecules")}>Voir toute la bibliothèque</button>} />
      </section>
    );
  }
  const active = groups.find((g) => g.id === id) ?? groups[0];
  return (
    <div className="stack">
      <section className="card">
        <SectionTitle eyebrow="En 3D">Les molécules de ce produit</SectionTitle>
        <p className="muted">Chaque ingrédient est fait de molécules. Choisis-en une pour la faire tourner.</p>
        <div className="chips scroll">
          {groups.map((g) => (
            <button key={g.id} className={`chip ${g.id === active.id ? "on" : ""}`} onClick={() => onPick(g.id)}>
              {getMolecule(g.id).name}
            </button>
          ))}
        </div>
        <MoleculeDetail moleculeId={active.id} intro={`Présente dans : ${active.names.join(", ")}.`} />
      </section>
    </div>
  );
}

function Details({ product }: { product: Product }) {
  const [own, setOwn] = useState(readPrice(product.barcode));
  const [price, setPrice] = useState("");
  const [store, setStore] = useState("");
  const typical = median(product.prices.map((p) => p.price));
  const cur = product.prices[0]?.currency ?? "EUR";

  function save(e: FormEvent) {
    e.preventDefault();
    const v = Number(price.replace(",", "."));
    if (!Number.isFinite(v) || v <= 0) return;
    const entry = { price: v, store: store.trim() || "Magasin non précisé", at: Date.now() };
    savePrice(product.barcode, entry);
    setOwn(entry);
    setPrice("");
    setStore("");
  }

  const facts: [string, string][] = [
    ["Pays de vente", placeLine(product.countries) || "Non renseigné"],
    ["Origine des ingrédients", product.origins || "Non renseignée"],
    ["Lieu de fabrication", product.manufacturing || "Non renseigné"],
    ["Emballage", product.packaging || "Non renseigné"],
    ["Code-barres", product.barcode],
  ];
  return (
    <div className="stack">
      <section className="card">
        <SectionTitle eyebrow="D'où ça vient">Traçabilité</SectionTitle>
        <dl className="facts col">{facts.map(([k, v]) => <div key={k}><dt>{k}</dt><dd>{v}</dd></div>)}</dl>
        {product.labels.length > 0 && <div className="chips wrap">{product.labels.map((l) => <span key={l} className="chip">{l}</span>)}</div>}
      </section>

      <section className="card">
        <SectionTitle eyebrow="Combien ça coûte">Prix</SectionTitle>
        {typical != null ? (
          <p className="lead">Prix constaté autour de <b>{formatPrice(typical, cur)}</b> <span className="muted small">(médiane de {product.prices.length} relevé{product.prices.length > 1 ? "s" : ""})</span></p>
        ) : (
          <p className="muted">Aucun prix collaboratif pour ce produit.</p>
        )}
        {product.prices.slice(0, 4).map((p, i) => (
          <p key={i} className="muted small">{formatPrice(p.price, p.currency)} · {p.store ?? "Magasin inconnu"}{p.city ? ` (${p.city})` : ""}</p>
        ))}
        {own && <p className="note">Ton relevé : <b>{formatPrice(own.price)}</b> chez {own.store}.</p>}
        <form className="price-form" onSubmit={save}>
          <input value={price} onChange={(e) => setPrice(e.target.value)} inputMode="decimal" placeholder="Prix payé (€)" aria-label="Prix payé" />
          <input value={store} onChange={(e) => setStore(e.target.value)} placeholder="Magasin" aria-label="Magasin" />
          <button className="btn ghost" type="submit">Enregistrer</button>
        </form>
      </section>

      <p className="muted small center">Données : Open Food Facts (licence ODbL). Les informations peuvent contenir des erreurs : vérifie toujours l'emballage.</p>
    </div>
  );
}
