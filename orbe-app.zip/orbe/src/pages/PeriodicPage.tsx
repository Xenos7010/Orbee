import { useMemo, useState } from "react";
import { CATEGORIES, ELEMENTS_LIST, ELEMENT_BY_SYMBOL, STATE_LABEL, type Category, type ChemElement } from "../data/elements";
import { ElementDetail } from "../components/ElementDetail";
import { IconSearch, IconSparkle } from "../components/icons";
import { Seg, Sheet, Toggle } from "../components/ui";
import { go } from "../router";

const plain = (s: string) => s.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase();

function matches(e: ChemElement, q: string, cat: Category | null, food: boolean) {
  if (cat && e.category !== cat) return false;
  if (food && !e.food) return false;
  if (!q) return true;
  const n = plain(q.trim());
  return plain(e.name).includes(n) || plain(e.sym) === n || plain(e.sym).startsWith(n) || String(e.z) === n;
}

function Quiz({ onClose }: { onClose: () => void }) {
  const pool = useMemo(() => ELEMENTS_LIST.filter((e) => e.z <= 36 || ["Ag", "Au", "Hg", "Pb", "Sn", "I", "U", "Pt", "W"].includes(e.sym)), []);
  const makeRound = () =>
    Array.from({ length: 8 }, () => {
      const target = pool[Math.floor(Math.random() * pool.length)];
      const mode = Math.random() < 0.5 ? "sym" : "name";
      const wrong = pool.filter((e) => e.z !== target.z).sort(() => Math.random() - 0.5).slice(0, 3);
      const options = [target, ...wrong].sort(() => Math.random() - 0.5);
      return { target, mode, options };
    });
  const [round, setRound] = useState(makeRound);
  const [i, setI] = useState(0);
  const [score, setScore] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);

  const finished = i >= round.length;
  const q = round[Math.min(i, round.length - 1)];

  function choose(z: number) {
    if (picked != null) return;
    setPicked(z);
    if (z === q.target.z) setScore((s) => s + 1);
  }
  function next() {
    setPicked(null);
    setI((v) => v + 1);
  }
  function restart() {
    setRound(makeRound());
    setI(0);
    setScore(0);
    setPicked(null);
  }

  return (
    <Sheet title="Quiz" onClose={onClose}>
      <div className="quiz">
        <span className="eyebrow">Quiz des éléments</span>
        {finished ? (
          <>
            <h3>{score} / {round.length}</h3>
            <p className="lead">
              {score >= 7 ? "Bravo, tu connais bien le tableau !" : score >= 4 ? "Pas mal ! Encore un tour pour progresser ?" : "Continue d'explorer le tableau, ça rentre vite."}
            </p>
            <div className="row-actions">
              <button className="btn primary" onClick={restart}>Rejouer</button>
              <button className="btn ghost" onClick={onClose}>Fermer</button>
            </div>
          </>
        ) : (
          <>
            <div className="quiz-progress"><span style={{ width: `${(i / round.length) * 100}%` }} /></div>
            <h3>
              {q.mode === "sym" ? <>Quel est le symbole de <em>{q.target.name}</em> ?</> : <>Quel élément a pour symbole <em>{q.target.sym}</em> ?</>}
            </h3>
            <div className="quiz-options">
              {q.options.map((o) => {
                const state = picked == null ? "" : o.z === q.target.z ? "right" : o.z === picked ? "wrong" : "dim";
                return (
                  <button key={o.z} className={`quiz-opt ${state}`} onClick={() => choose(o.z)}>
                    {q.mode === "sym" ? o.sym : o.name}
                  </button>
                );
              })}
            </div>
            {picked != null && (
              <div className="quiz-feedback">
                <p>
                  {picked === q.target.z ? "Exact !" : `Pas tout à fait : ${q.target.name} s'écrit ${q.target.sym}.`} {q.target.use}
                </p>
                <button className="btn primary" onClick={next}>{i === round.length - 1 ? "Voir mon score" : "Question suivante"}</button>
              </div>
            )}
          </>
        )}
      </div>
    </Sheet>
  );
}

export function PeriodicPage({ sym }: { sym: string | null }) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<Category | null>(null);
  const [food, setFood] = useState(false);
  const [view, setView] = useState<"grille" | "liste">("grille");
  const [size, setSize] = useState<"s" | "m" | "l">("m");
  const [quiz, setQuiz] = useState(false);

  const selected = sym ? ELEMENT_BY_SYMBOL[sym] : undefined;
  const hits = useMemo(() => ELEMENTS_LIST.filter((e) => matches(e, q, cat, food)), [q, cat, food]);
  const hitSet = useMemo(() => new Set(hits.map((e) => e.z)), [hits]);
  const px = size === "s" ? 38 : size === "m" ? 50 : 66;

  return (
    <div className="page">
      <header className="page-head">
        <div className="head-row">
          <div>
            <span className="eyebrow">118 éléments</span>
            <h1>Tableau périodique</h1>
          </div>
          <button className="btn ghost small" onClick={() => setQuiz(true)}><IconSparkle /> Quiz</button>
        </div>
        <p className="muted">
          Chaque case est un élément chimique, la brique de base de toute la matière. Touche-en un pour tout savoir.
        </p>
      </header>

      <div className="search">
        <IconSearch />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Chercher : fer, Au, 26…" aria-label="Chercher un élément" inputMode="search" />
      </div>

      <div className="chips scroll" aria-label="Familles d'éléments">
        <button className={`chip ${cat === null ? "on" : ""}`} onClick={() => setCat(null)}>Toutes</button>
        {(Object.keys(CATEGORIES) as Category[]).map((c) => (
          <button key={c} className={`chip ${cat === c ? "on" : ""}`} onClick={() => setCat(cat === c ? null : c)}>
            <span className="dot" style={{ background: CATEGORIES[c].color }} />
            {CATEGORIES[c].label}
          </button>
        ))}
      </div>
      {cat && <p className="cat-hint" style={{ borderColor: CATEGORIES[cat].color }}>{CATEGORIES[cat].hint}</p>}

      <div className="toolbar">
        <Toggle on={food} onChange={setFood}>Dans l'alimentation</Toggle>
        <Seg value={view} onChange={setView} label="Affichage" options={[{ value: "grille", label: "Grille" }, { value: "liste", label: "Liste" }]} />
      </div>

      {view === "grille" ? (
        <>
          <div className="zoom">
            <span className="muted small">Taille</span>
            <Seg value={size} onChange={setSize} label="Taille des cases" options={[{ value: "s", label: "S" }, { value: "m", label: "M" }, { value: "l", label: "L" }]} />
            <span className="muted small hide-wide">Fais défiler →</span>
          </div>
          <div className="ptable-scroll">
            <div className="ptable" style={{ ["--cell" as string]: `${px}px` }}>
              <span className="stub" style={{ gridRow: 6, gridColumn: 3, color: CATEGORIES.lanthanide.color }}>57–71</span>
              <span className="stub" style={{ gridRow: 7, gridColumn: 3, color: CATEGORIES.actinide.color }}>89–103</span>
              {ELEMENTS_LIST.map((e) => {
                const c = CATEGORIES[e.category].color;
                const on = hitSet.has(e.z);
                return (
                  <button
                    key={e.z}
                    className={`cell ${on ? "" : "dim"} ${e.sym === sym ? "sel" : ""}`}
                    style={{ gridRow: e.row, gridColumn: e.col, ["--c" as string]: c }}
                    onClick={() => go(`/tableau/${e.sym}`)}
                    aria-label={`${e.name}, numéro ${e.z}`}
                  >
                    <small>{e.z}</small>
                    <b>{e.sym}</b>
                    {size !== "s" && <span>{e.name}</span>}
                  </button>
                );
              })}
            </div>
          </div>
          <p className="muted small">
            Les lignes du bas (lanthanides et actinides) sont normalement insérées dans les cases « 57–71 » et « 89–103 ».
            Les colonnes regroupent des éléments aux comportements proches.
          </p>
        </>
      ) : (
        <ul className="list el-list">
          {hits.map((e) => (
            <li key={e.z}>
              <button className="row" onClick={() => go(`/tableau/${e.sym}`)}>
                <span className="el-chip" style={{ ["--c" as string]: CATEGORIES[e.category].color }}>{e.sym}</span>
                <span className="grow">
                  <strong>{e.name}</strong>
                  <small>n° {e.z} · {CATEGORIES[e.category].short} · {STATE_LABEL[e.state]}</small>
                </span>
                <span className="muted small">{e.mass.toLocaleString("fr-FR")}</span>
              </button>
            </li>
          ))}
          {hits.length === 0 && <li className="muted pad">Aucun élément ne correspond.</li>}
        </ul>
      )}

      {selected && (
        <Sheet title={selected.name} onClose={() => go("/tableau")}>
          <ElementDetail el={selected} />
        </Sheet>
      )}
      {quiz && <Quiz onClose={() => setQuiz(false)} />}
    </div>
  );
}
