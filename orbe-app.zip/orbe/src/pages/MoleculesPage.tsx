import { useMemo, useState } from "react";
import { MiniMolecule, MoleculeDetail } from "../components/MoleculeDetail";
import { IconSearch } from "../components/icons";
import { Sheet, prettyFormula } from "../components/ui";
import { LIBRARY_ORDER, MOLECULES } from "../lib/molecules";
import { go, href } from "../router";

const plain = (s: string) => s.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase();

export function MoleculesPage({ id }: { id: string | null }) {
  const [q, setQ] = useState("");
  const [family, setFamily] = useState<string | null>(null);
  const all = useMemo(() => LIBRARY_ORDER.map((k) => MOLECULES[k]).filter(Boolean), []);
  const families = useMemo(() => [...new Set(all.map((m) => m.family))], [all]);
  const shown = all.filter(
    (m) => (!family || m.family === family) && (!q || plain(m.name).includes(plain(q)) || plain(m.formula).includes(plain(q))),
  );
  const selected = id ? MOLECULES[id] : undefined;

  return (
    <div className="page">
      <header className="page-head">
        <span className="eyebrow">{all.length} molécules</span>
        <h1>Molécules</h1>
        <p className="muted">
          Une molécule, ce sont des atomes accrochés entre eux. Ouvre-en une pour la voir en 3D et la faire tourner.
        </p>
      </header>

      <div className="search">
        <IconSearch />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Eau, glucose, CO2…" aria-label="Chercher une molécule" />
      </div>
      <div className="chips scroll">
        <button className={`chip ${family === null ? "on" : ""}`} onClick={() => setFamily(null)}>Toutes</button>
        {families.map((f) => (
          <button key={f} className={`chip ${family === f ? "on" : ""}`} onClick={() => setFamily(family === f ? null : f)}>{f}</button>
        ))}
      </div>

      <div className="mol-grid">
        {shown.map((m) => (
          <a key={m.id} className="mol-card" href={href(`/molecules/${m.id}`)}>
            <MiniMolecule molecule={m} />
            <strong>{m.name}</strong>
            <span className="formula">{prettyFormula(m.formula)}</span>
            <small>{m.family}{m.schematic ? " · simplifiée" : ""}</small>
          </a>
        ))}
        {shown.length === 0 && <p className="muted pad">Aucune molécule ne correspond.</p>}
      </div>

      {selected && (
        <Sheet title={selected.name} onClose={() => go("/molecules")}>
          <MoleculeDetail moleculeId={selected.id} />
        </Sheet>
      )}
    </div>
  );
}
