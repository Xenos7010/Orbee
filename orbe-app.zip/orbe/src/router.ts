import { useEffect, useState } from "react";

/** Routage par hash (#/produit/123) : fonctionne dans un APK, sans serveur. */
function current(): string {
  const raw = window.location.hash.replace(/^#/, "");
  return raw.startsWith("/") ? raw : "/";
}

export function useRoute(): string {
  const [path, setPath] = useState(current);
  useEffect(() => {
    const on = () => setPath(current());
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return path;
}

export function go(path: string) {
  window.location.hash = path;
}

export function back(fallback = "/") {
  if (window.history.length > 1) window.history.back();
  else go(fallback);
}

export function href(path: string) {
  return `#${path}`;
}
