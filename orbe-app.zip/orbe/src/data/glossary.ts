export const GLOSSARY: { term: string; def: string }[] = [
  { term: "Atome", def: "La plus petite brique de matière d'un élément. Un atome d'oxygène, un atome de carbone…" },
  { term: "Élément", def: "Un type d'atome, comme l'oxygène (O) ou le fer (Fe). Le tableau périodique en liste 118." },
  { term: "Molécule", def: "Plusieurs atomes liés ensemble. L'eau (H₂O) est une molécule de 3 atomes : 2 hydrogènes et 1 oxygène." },
  { term: "Liaison", def: "Le « lien » qui tient deux atomes ensemble. Simple, double ou triple selon le nombre de paires d'électrons partagées." },
  { term: "Formule chimique", def: "Le code d'une molécule : les symboles des atomes et leur nombre en petit. C₆H₁₂O₆ = 6 carbones, 12 hydrogènes, 6 oxygènes." },
  { term: "Masse molaire", def: "Le « poids » d'une molécule, exprimé en g/mol. Plus il y a d'atomes lourds, plus elle est élevée." },
  { term: "Glucides", def: "Les sucres et l'amidon. Ils apportent de l'énergie rapidement." },
  { term: "Lipides", def: "Les graisses et les huiles. Ils apportent beaucoup d'énergie et aident à absorber certaines vitamines." },
  { term: "Protéines", def: "De longues chaînes d'acides aminés. Elles construisent les muscles et la plupart des tissus." },
  { term: "Nutri-Score", def: "Une note de A (vert) à E (rouge) qui résume la qualité nutritionnelle d'un aliment : plutôt bon (fibres, protéines) ou à limiter (sucre, sel, graisses saturées)." },
  { term: "NOVA", def: "Une classification de 1 à 4 selon le degré de transformation. 1 = brut ou peu transformé, 4 = ultra-transformé (beaucoup d'additifs et d'ingrédients industriels)." },
  { term: "Éco-Score", def: "Une note de A à E sur l'impact environnemental du produit : culture, transport, emballage." },
  { term: "Additif (code E)", def: "Une substance ajoutée pour la conservation, la couleur, la texture ou le goût. Chaque additif autorisé en Europe reçoit un code qui commence par E." },
  { term: "Émulsifiant", def: "Il permet de mélanger l'eau et l'huile, qui ne se mélangent pas naturellement. La lécithine en est un exemple." },
  { term: "Pour 100 g", def: "Les valeurs nutritionnelles sont toujours données pour 100 g (ou 100 ml) afin de pouvoir comparer les produits entre eux." },
  { term: "Électron", def: "Une particule minuscule qui tourne autour du noyau de l'atome. Ceux de la couche externe décident des liaisons possibles." },
  { term: "Numéro atomique", def: "Le nombre de protons dans le noyau. C'est la carte d'identité de l'élément : 1 pour l'hydrogène, 8 pour l'oxygène…" },
];

export const SCORE_TEXT: Record<"nutri" | "nova" | "eco", Record<string, { title: string; text: string; tone: "good" | "ok" | "warn" | "bad" }>> = {
  nutri: {
    a: { title: "Très bonne qualité", text: "Un des meilleurs choix nutritionnels de sa catégorie.", tone: "good" },
    b: { title: "Bonne qualité", text: "Un choix plutôt favorable pour la santé.", tone: "good" },
    c: { title: "Qualité moyenne", text: "Correct, à consommer sans excès.", tone: "ok" },
    d: { title: "Qualité médiocre", text: "Trop de sucre, de sel ou de graisses saturées. À limiter.", tone: "warn" },
    e: { title: "À consommer occasionnellement", text: "Nutritionnellement peu favorable. Pour le plaisir, en petites quantités.", tone: "bad" },
  },
  nova: {
    "1": { title: "Brut ou peu transformé", text: "Fruits, légumes, œufs, lait… tels quels ou presque.", tone: "good" },
    "2": { title: "Ingrédient culinaire", text: "Huile, beurre, sucre, sel : on les utilise pour cuisiner.", tone: "good" },
    "3": { title: "Transformé", text: "Conserves, fromages, pain : des aliments simples auxquels on a ajouté du sel, du sucre ou de l'huile.", tone: "ok" },
    "4": { title: "Ultra-transformé", text: "Recette industrielle avec additifs. Mieux vaut ne pas en abuser.", tone: "bad" },
  },
  eco: {
    a: { title: "Impact très faible", text: "Faible empreinte environnementale.", tone: "good" },
    b: { title: "Impact faible", text: "Un bon choix pour la planète.", tone: "good" },
    c: { title: "Impact modéré", text: "Dans la moyenne.", tone: "ok" },
    d: { title: "Impact élevé", text: "Production ou transport assez lourds.", tone: "warn" },
    e: { title: "Impact très élevé", text: "Une des plus fortes empreintes de sa catégorie.", tone: "bad" },
  },
};
