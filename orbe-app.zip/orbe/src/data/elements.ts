export type Category =
  | "nonmetal"
  | "noble"
  | "alcalin"
  | "alcalino"
  | "metalloide"
  | "post"
  | "halogene"
  | "transition"
  | "lanthanide"
  | "actinide"
  | "inconnu";

export type State = "gaz" | "liquide" | "solide" | "inconnu";

export type ChemElement = {
  z: number;
  sym: string;
  name: string;
  mass: number;
  massApprox: boolean;
  category: Category;
  state: State;
  row: number;
  col: number;
  shells: number[];
  use: string;
  food: string | null;
};

export const CATEGORIES: Record<Category, { label: string; short: string; hint: string; color: string }> = {
  nonmetal: {
    label: "Non-métaux",
    short: "Non-métal",
    hint: "Éléments de la vie : carbone, oxygène, azote… Ils forment la plupart des molécules du vivant.",
    color: "#5eead4",
  },
  noble: {
    label: "Gaz nobles",
    short: "Gaz noble",
    hint: "Presque inertes : ils réagissent très rarement avec les autres éléments.",
    color: "#c4b5fd",
  },
  alcalin: {
    label: "Métaux alcalins",
    short: "Métal alcalin",
    hint: "Métaux mous et très réactifs, surtout avec l'eau.",
    color: "#fda4af",
  },
  alcalino: {
    label: "Alcalino-terreux",
    short: "Alcalino-terreux",
    hint: "Métaux assez réactifs. Le calcium et le magnésium en font partie.",
    color: "#fdba74",
  },
  metalloide: {
    label: "Métalloïdes",
    short: "Métalloïde",
    hint: "À mi-chemin entre métal et non-métal. Le silicium des puces électroniques en fait partie.",
    color: "#a7f3d0",
  },
  post: {
    label: "Autres métaux",
    short: "Métal pauvre",
    hint: "Métaux plus mous et plus fusibles que les métaux de transition (aluminium, plomb, étain).",
    color: "#93c5fd",
  },
  halogene: {
    label: "Halogènes",
    short: "Halogène",
    hint: "Très réactifs. Ils forment des sels avec les métaux : chlore, iode, fluor.",
    color: "#fde68a",
  },
  transition: {
    label: "Métaux de transition",
    short: "Métal de transition",
    hint: "Les métaux « classiques » : fer, cuivre, or, argent… Durs et bons conducteurs.",
    color: "#7dd3fc",
  },
  lanthanide: {
    label: "Lanthanides",
    short: "Lanthanide",
    hint: "Les « terres rares », utilisées dans les aimants et les écrans.",
    color: "#f9a8d4",
  },
  actinide: {
    label: "Actinides",
    short: "Actinide",
    hint: "Tous radioactifs. L'uranium et le plutonium en font partie.",
    color: "#f0abfc",
  },
  inconnu: {
    label: "Synthétiques récents",
    short: "Synthétique",
    hint: "Créés en laboratoire, ils existent quelques millisecondes. Leurs propriétés sont mal connues.",
    color: "#a1a1aa",
  },
};

const RAW = `1|H|Hydrogène|1.008
2|He|Hélium|4.0026
3|Li|Lithium|6.94
4|Be|Béryllium|9.0122
5|B|Bore|10.81
6|C|Carbone|12.011
7|N|Azote|14.007
8|O|Oxygène|15.999
9|F|Fluor|18.998
10|Ne|Néon|20.18
11|Na|Sodium|22.99
12|Mg|Magnésium|24.305
13|Al|Aluminium|26.982
14|Si|Silicium|28.085
15|P|Phosphore|30.974
16|S|Soufre|32.06
17|Cl|Chlore|35.45
18|Ar|Argon|39.95
19|K|Potassium|39.098
20|Ca|Calcium|40.078
21|Sc|Scandium|44.956
22|Ti|Titane|47.867
23|V|Vanadium|50.942
24|Cr|Chrome|51.996
25|Mn|Manganèse|54.938
26|Fe|Fer|55.845
27|Co|Cobalt|58.933
28|Ni|Nickel|58.693
29|Cu|Cuivre|63.546
30|Zn|Zinc|65.38
31|Ga|Gallium|69.723
32|Ge|Germanium|72.63
33|As|Arsenic|74.922
34|Se|Sélénium|78.971
35|Br|Brome|79.904
36|Kr|Krypton|83.798
37|Rb|Rubidium|85.468
38|Sr|Strontium|87.62
39|Y|Yttrium|88.906
40|Zr|Zirconium|91.224
41|Nb|Niobium|92.906
42|Mo|Molybdène|95.95
43|Tc|Technétium|98
44|Ru|Ruthénium|101.07
45|Rh|Rhodium|102.91
46|Pd|Palladium|106.42
47|Ag|Argent|107.87
48|Cd|Cadmium|112.41
49|In|Indium|114.82
50|Sn|Étain|118.71
51|Sb|Antimoine|121.76
52|Te|Tellure|127.6
53|I|Iode|126.9
54|Xe|Xénon|131.29
55|Cs|Césium|132.91
56|Ba|Baryum|137.33
57|La|Lanthane|138.91
58|Ce|Cérium|140.12
59|Pr|Praséodyme|140.91
60|Nd|Néodyme|144.24
61|Pm|Prométhium|145
62|Sm|Samarium|150.36
63|Eu|Europium|151.96
64|Gd|Gadolinium|157.25
65|Tb|Terbium|158.93
66|Dy|Dysprosium|162.5
67|Ho|Holmium|164.93
68|Er|Erbium|167.26
69|Tm|Thulium|168.93
70|Yb|Ytterbium|173.05
71|Lu|Lutécium|174.97
72|Hf|Hafnium|178.49
73|Ta|Tantale|180.95
74|W|Tungstène|183.84
75|Re|Rhénium|186.21
76|Os|Osmium|190.23
77|Ir|Iridium|192.22
78|Pt|Platine|195.08
79|Au|Or|196.97
80|Hg|Mercure|200.59
81|Tl|Thallium|204.38
82|Pb|Plomb|207.2
83|Bi|Bismuth|208.98
84|Po|Polonium|209
85|At|Astate|210
86|Rn|Radon|222
87|Fr|Francium|223
88|Ra|Radium|226
89|Ac|Actinium|227
90|Th|Thorium|232.04
91|Pa|Protactinium|231.04
92|U|Uranium|238.03
93|Np|Neptunium|237
94|Pu|Plutonium|244
95|Am|Américium|243
96|Cm|Curium|247
97|Bk|Berkélium|247
98|Cf|Californium|251
99|Es|Einsteinium|252
100|Fm|Fermium|257
101|Md|Mendélévium|258
102|No|Nobélium|259
103|Lr|Lawrencium|266
104|Rf|Rutherfordium|267
105|Db|Dubnium|268
106|Sg|Seaborgium|269
107|Bh|Bohrium|270
108|Hs|Hassium|277
109|Mt|Meitnérium|278
110|Ds|Darmstadtium|281
111|Rg|Roentgenium|282
112|Cn|Copernicium|285
113|Nh|Nihonium|286
114|Fl|Flérovium|289
115|Mc|Moscovium|290
116|Lv|Livermorium|293
117|Ts|Tennesse|294
118|Og|Oganesson|294`;

/** Éléments dont la masse est un nombre de masse (pas de masse atomique standard). */
const NO_STANDARD_MASS = new Set([43, 61, ...Array.from({ length: 118 - 83 }, (_, i) => i + 84)].filter((z) => z !== 90 && z !== 91 && z !== 92));

function categoryOf(z: number): Category {
  if ([3, 11, 19, 37, 55, 87].includes(z)) return "alcalin";
  if ([4, 12, 20, 38, 56, 88].includes(z)) return "alcalino";
  if (z >= 57 && z <= 71) return "lanthanide";
  if (z >= 89 && z <= 103) return "actinide";
  if ((z >= 21 && z <= 30) || (z >= 39 && z <= 48) || (z >= 72 && z <= 80) || (z >= 104 && z <= 108)) return "transition";
  if ([5, 14, 32, 33, 51, 52].includes(z)) return "metalloide";
  if ([13, 31, 49, 50, 81, 82, 83, 84].includes(z)) return "post";
  if ([9, 17, 35, 53, 85].includes(z)) return "halogene";
  if ([2, 10, 18, 36, 54, 86].includes(z)) return "noble";
  if ([1, 6, 7, 8, 15, 16, 34].includes(z)) return "nonmetal";
  return "inconnu";
}

function stateOf(z: number): State {
  if ([1, 2, 7, 8, 9, 10, 17, 18, 36, 54, 86].includes(z)) return "gaz";
  if ([35, 80].includes(z)) return "liquide";
  if (z >= 109) return "inconnu";
  return "solide";
}

/** Position dans la grille 18 colonnes (lanthanides et actinides sur deux lignes séparées). */
function positionOf(z: number): { row: number; col: number } {
  if (z === 1) return { row: 1, col: 1 };
  if (z === 2) return { row: 1, col: 18 };
  if (z <= 4) return { row: 2, col: z - 2 };
  if (z <= 10) return { row: 2, col: z + 8 };
  if (z <= 12) return { row: 3, col: z - 10 };
  if (z <= 18) return { row: 3, col: z };
  if (z <= 36) return { row: 4, col: z - 18 };
  if (z <= 54) return { row: 5, col: z - 36 };
  if (z <= 56) return { row: 6, col: z - 54 };
  if (z <= 71) return { row: 9, col: z - 54 };
  if (z <= 86) return { row: 6, col: z - 68 };
  if (z <= 88) return { row: 7, col: z - 86 };
  if (z <= 103) return { row: 10, col: z - 86 };
  return { row: 7, col: z - 100 };
}

const ORDER: [number, number][] = [
  [1, 2], [2, 2], [2, 6], [3, 2], [3, 6], [4, 2], [3, 10], [4, 6], [5, 2], [4, 10], [5, 6],
  [6, 2], [4, 14], [5, 10], [6, 6], [7, 2], [5, 14], [6, 10], [7, 6],
];

/** Exceptions connues au remplissage théorique des couches. */
const SHELL_EXCEPTIONS: Record<number, number[]> = {
  24: [2, 8, 13, 1],
  29: [2, 8, 18, 1],
  41: [2, 8, 18, 12, 1],
  42: [2, 8, 18, 13, 1],
  44: [2, 8, 18, 15, 1],
  45: [2, 8, 18, 16, 1],
  46: [2, 8, 18, 18],
  47: [2, 8, 18, 18, 1],
  57: [2, 8, 18, 18, 9, 2],
  58: [2, 8, 18, 19, 9, 2],
  64: [2, 8, 18, 25, 9, 2],
  78: [2, 8, 18, 32, 17, 1],
  79: [2, 8, 18, 32, 18, 1],
  89: [2, 8, 18, 32, 18, 9, 2],
  90: [2, 8, 18, 32, 18, 10, 2],
  91: [2, 8, 18, 32, 20, 9, 2],
  92: [2, 8, 18, 32, 21, 9, 2],
  93: [2, 8, 18, 32, 22, 9, 2],
  96: [2, 8, 18, 32, 25, 9, 2],
};

function shellsOf(z: number): number[] {
  if (SHELL_EXCEPTIONS[z]) return SHELL_EXCEPTIONS[z];
  const shells: number[] = [];
  let left = z;
  for (const [n, cap] of ORDER) {
    if (left <= 0) break;
    const take = Math.min(cap, left);
    shells[n - 1] = (shells[n - 1] ?? 0) + take;
    left -= take;
  }
  return Array.from(shells, (v) => v ?? 0);
}

const USE: Record<string, string> = {
  H: "L'élément le plus abondant de l'univers. Il fait partie de l'eau et de presque toutes les molécules du vivant.",
  He: "Fait voler les ballons et refroidit les IRM des hôpitaux. Il ne réagit avec rien.",
  Li: "Au cœur des batteries de téléphones et de voitures électriques.",
  Be: "Alliages légers et rigides, utilisés dans l'aérospatiale.",
  B: "Verre résistant à la chaleur (type Pyrex) et produits d'entretien.",
  C: "La brique de la vie. Diamant, graphite, sucre, plastique : tout vient du carbone.",
  N: "Il fait 78 % de l'air que tu respires. Il entre aussi dans les protéines.",
  O: "Indispensable pour respirer. Il compose l'eau, l'air et la plupart des roches.",
  F: "Protège l'émail dentaire dans les dentifrices. Le Téflon en contient aussi.",
  Ne: "Donne leur lueur rouge-orangé aux enseignes lumineuses.",
  Na: "Associé au chlore, il forme le sel de table. Métal qui explose presque au contact de l'eau.",
  Mg: "Au centre de la chlorophylle des plantes. Léger, il sert aussi dans les alliages.",
  Al: "Canettes, papier d'aluminium, avions. Léger et ne rouille pas.",
  Si: "Base des puces électroniques, du verre et du sable.",
  P: "Dans l'ADN, les os et l'ATP, la « batterie » des cellules. On le trouve aussi dans les engrais.",
  S: "Odeur des œufs pourris et de l'allumette. Il se trouve dans certaines protéines.",
  Cl: "Désinfecte l'eau des piscines. Avec le sodium, il fait le sel de cuisine.",
  Ar: "Gaz inerte qui remplit certaines ampoules.",
  K: "Régule les muscles et le cœur. Abondant dans la banane et la pomme de terre.",
  Ca: "Os, dents, coquilles et lait. Le calcaire en est riche.",
  Ti: "Prothèses, montures de lunettes, avions : solide et léger.",
  Cr: "Donne son éclat au chrome des robinets et à l'acier inoxydable.",
  Mn: "Rend l'acier plus dur. Indispensable en très petite quantité à l'organisme.",
  Fe: "Dans l'acier, et dans l'hémoglobine qui transporte l'oxygène dans le sang.",
  Co: "Pigment bleu des céramiques, batteries et vitamine B12.",
  Ni: "Pièces de monnaie, acier inoxydable et batteries.",
  Cu: "Fils électriques, casseroles, tuyaux. Excellent conducteur.",
  Zn: "Protège l'acier de la rouille (galvanisation). Aide le système immunitaire.",
  Ga: "Fond dans la main. Utilisé dans les LED et les smartphones.",
  Se: "Oligo-élément antioxydant, présent dans la noix du Brésil.",
  Br: "Un des deux seuls éléments liquides à température ambiante. Odeur très forte.",
  Kr: "Gaz rare utilisé dans certains éclairages et flashs photo.",
  Mo: "Durcit les aciers. Utile en infime quantité dans l'organisme.",
  Ag: "Bijoux, miroirs et pièces. Meilleur conducteur électrique connu.",
  Sn: "Boîtes de conserve (fer-blanc) et soudures.",
  I: "Indispensable à la thyroïde. On l'ajoute parfois au sel de table.",
  Xe: "Phares de voiture très puissants et propulsion de sondes spatiales.",
  Ba: "Utilisé en imagerie médicale (repas baryté) et dans les feux d'artifice verts.",
  W: "Le métal qui fond le plus difficilement. Il formait le filament des anciennes ampoules.",
  Pt: "Pots catalytiques, bijoux et traitements contre le cancer.",
  Au: "Métal précieux qui ne s'oxyde pas. Bijoux, électronique et réserves des banques.",
  Hg: "Seul métal liquide à température ambiante. Toxique, il a quitté les thermomètres.",
  Pb: "Autrefois dans les canalisations et la peinture. Toxique, il est aujourd'hui très encadré.",
  Rn: "Gaz radioactif naturel qui peut s'accumuler dans les caves.",
  Ra: "Découvert par Marie Curie. Sa radioactivité l'a rendu célèbre.",
  U: "Combustible des centrales nucléaires.",
  Pu: "Sous-produit des réacteurs nucléaires. Très radioactif et toxique.",
};

const FOOD: Record<string, string> = {
  H: "Dans l'eau et dans tous les aliments.",
  C: "Squelette de tous les glucides, lipides et protéines.",
  N: "Indispensable pour fabriquer les protéines.",
  O: "Dans l'eau et dans presque toutes les molécules des aliments.",
  Na: "Apporté surtout par le sel. À limiter en excès.",
  Mg: "Noix, légumes verts, chocolat noir.",
  P: "Os et dents. Dans les produits laitiers, les viandes, les céréales.",
  S: "Dans les protéines : œufs, viandes, ail, oignon.",
  Cl: "Apporté par le sel de table.",
  K: "Bananes, pommes de terre, légumineuses.",
  Ca: "Lait, fromages, sardines, eaux minérales.",
  Mn: "Céréales complètes, noix.",
  Fe: "Viandes rouges, lentilles, épinards.",
  Co: "Contenu dans la vitamine B12.",
  Cu: "Fruits à coque, chocolat, fruits de mer.",
  Zn: "Huîtres, viandes, graines de courge.",
  Se: "Noix du Brésil, poissons.",
  Mo: "Légumineuses, céréales.",
  I: "Poissons, produits de la mer, sel iodé.",
  F: "Eau, thé, dentifrice.",
  Cr: "Brocoli, céréales complètes (en très petite quantité).",
};

const BY_CATEGORY_USE: Record<Category, string> = {
  nonmetal: "Élément essentiel à la chimie du vivant.",
  noble: "Gaz presque inerte, souvent utilisé pour l'éclairage ou comme gaz protecteur.",
  alcalin: "Métal très réactif, jamais trouvé à l'état pur dans la nature.",
  alcalino: "Métal réactif, présent dans de nombreux minéraux.",
  metalloide: "Matériau aux propriétés intermédiaires, utile en électronique et en verrerie.",
  post: "Métal assez mou, utilisé dans des alliages et l'électronique.",
  halogene: "Élément très réactif qui forme des sels avec les métaux.",
  transition: "Métal dur et conducteur, utilisé dans les alliages et la catalyse.",
  lanthanide: "Terre rare, utilisée dans les aimants, les lasers et les écrans.",
  actinide: "Élément radioactif. Quelques-uns servent dans l'industrie nucléaire.",
  inconnu: "Élément créé en laboratoire. Il existe quelques instants avant de se désintégrer.",
};

export const ELEMENTS_LIST: ChemElement[] = RAW.split("\n").map((line) => {
  const [zs, sym, name, mass] = line.split("|");
  const z = Number(zs);
  const category = categoryOf(z);
  return {
    z,
    sym,
    name,
    mass: Number(mass),
    massApprox: NO_STANDARD_MASS.has(z),
    category,
    state: stateOf(z),
    ...positionOf(z),
    shells: shellsOf(z),
    use: USE[sym] ?? BY_CATEGORY_USE[category],
    food: FOOD[sym] ?? null,
  };
});

export const ELEMENT_BY_SYMBOL: Record<string, ChemElement> = Object.fromEntries(
  ELEMENTS_LIST.map((e) => [e.sym, e]),
);

export const STATE_LABEL: Record<State, string> = {
  gaz: "Gaz",
  liquide: "Liquide",
  solide: "Solide",
  inconnu: "Inconnu",
};
