import { useEffect, useRef } from "react";
import { ELEMENTS, type Molecule } from "../lib/molecules";

type Props = {
  molecule: Molecule;
  showH: boolean;
  volume: boolean;
  labels: boolean;
  selected: number | null;
  onSelect: (index: number | null) => void;
  /** Hauteur CSS du canvas */
  height?: number;
};

type Draw =
  | { t: "a"; i: number; z: number; x: number; y: number; r: number }
  | { t: "b"; a: number; b: number; z: number; order: number; ionic: boolean };

function parseHex(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

function mix(hex: string, target: [number, number, number], t: number): string {
  const [r, g, b] = parseHex(hex);
  const m = (a: number, c: number) => Math.round(a + (c - a) * t);
  return `rgb(${m(r, target[0])},${m(g, target[1])},${m(b, target[2])})`;
}

/** Les éléments très sombres (carbone) sont éclaircis pour rester lisibles sur fond noir. */
function baseColor(el: string): string {
  const c = ELEMENTS[el as keyof typeof ELEMENTS].color;
  const [r, g, b] = parseHex(c);
  const lum = 0.299 * r + 0.587 * g + 0.114 * b;
  if (lum < 70) return "#5b5f6b";
  return c;
}

export function MoleculeViewer({ molecule, showH, volume, labels, selected, onSelect, height = 320 }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const live = useRef({ molecule, showH, volume, labels, selected, onSelect });
  live.current = { molecule, showH, volume, labels, selected, onSelect };

  const view = useRef({ yaw: 0.6, pitch: -0.35, zoom: 1, idle: 0, dragging: false });
  const drawn = useRef<{ i: number; x: number; y: number; r: number; z: number }[]>([]);

  // Réinitialise la vue quand on change de molécule
  useEffect(() => {
    view.current.yaw = 0.6;
    view.current.pitch = -0.35;
    view.current.zoom = 1;
  }, [molecule.id]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    let raf = 0;
    let last = performance.now();
    let w = 0;
    let h = 0;
    let dpr = 1;

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = Math.max(1, Math.round(w * dpr));
      canvas.height = Math.max(1, Math.round(h * dpr));
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const v = view.current;
      if (!reduce && !v.dragging) {
        v.idle += dt;
        if (v.idle > 1.8) v.yaw += dt * 0.35;
      }
      render(ctx, w, h, dpr);
      raf = requestAnimationFrame(frame);
    };

    const render = (c: CanvasRenderingContext2D, W: number, H: number, ratio: number) => {
      const { molecule: mol, showH: sh, volume: vol, labels: lab, selected: sel } = live.current;
      c.setTransform(ratio, 0, 0, ratio, 0, 0);
      c.clearRect(0, 0, W, H);
      const v = view.current;
      const atoms = mol.atoms;
      if (!atoms.length) return;

      // centre géométrique
      let cx = 0, cy = 0, cz = 0;
      for (const a of atoms) { cx += a.p[0]; cy += a.p[1]; cz += a.p[2]; }
      cx /= atoms.length; cy /= atoms.length; cz /= atoms.length;

      const radiusOf = (el: string) => ELEMENTS[el as keyof typeof ELEMENTS].radius * (vol ? 2.9 : 1);
      let R = 0.5;
      for (const a of atoms) {
        if (!sh && a.el === "H") continue;
        const d = Math.hypot(a.p[0] - cx, a.p[1] - cy, a.p[2] - cz) + radiusOf(a.el);
        if (d > R) R = d;
      }
      const D = R * 5;
      const k = ((Math.min(W, H) / 2) * 0.92 * v.zoom) / R;
      const cosY = Math.cos(v.yaw), sinY = Math.sin(v.yaw);
      const cosX = Math.cos(v.pitch), sinX = Math.sin(v.pitch);

      const pts = atoms.map((a) => {
        const x = a.p[0] - cx, y = a.p[1] - cy, z = a.p[2] - cz;
        const x1 = x * cosY + z * sinY;
        const z1 = -x * sinY + z * cosY;
        const y2 = y * cosX - z1 * sinX;
        const z2 = y * sinX + z1 * cosX;
        const persp = D / (D - z2);
        return { x: W / 2 + x1 * k * persp, y: H / 2 - y2 * k * persp, z: z2, persp };
      });

      const list: Draw[] = [];
      atoms.forEach((a, i) => {
        if (!sh && a.el === "H") return;
        const p = pts[i];
        list.push({ t: "a", i, z: p.z, x: p.x, y: p.y, r: radiusOf(a.el) * k * p.persp });
      });
      if (!vol) {
        for (const b of mol.bonds) {
          if (!sh && (atoms[b.a].el === "H" || atoms[b.b].el === "H")) continue;
          list.push({ t: "b", a: b.a, b: b.b, z: (pts[b.a].z + pts[b.b].z) / 2, order: b.order, ionic: Boolean(b.ionic) });
        }
      }
      list.sort((p, q) => p.z - q.z);

      const hits: typeof drawn.current = [];
      for (const item of list) {
        if (item.t === "b") {
          const A = pts[item.a], B = pts[item.b];
          const dx = B.x - A.x, dy = B.y - A.y;
          const len = Math.hypot(dx, dy) || 1;
          const nx = -dy / len, ny = dx / len;
          const persp = (A.persp + B.persp) / 2;
          const gap = 0.2 * k * persp;
          const width = Math.max(2, 0.16 * k * persp * (item.order > 1 ? 0.7 : 1));
          const offsets = item.order === 1 ? [0] : item.order === 2 ? [-0.5, 0.5] : [-1, 0, 1];
          c.lineCap = "round";
          for (const o of offsets) {
            const ox = nx * gap * o, oy = ny * gap * o;
            c.beginPath();
            c.moveTo(A.x + ox, A.y + oy);
            c.lineTo(B.x + ox, B.y + oy);
            if (item.ionic) {
              c.setLineDash([4, 5]);
              c.strokeStyle = "rgba(255,255,255,0.35)";
              c.lineWidth = 1.5;
            } else {
              c.setLineDash([]);
              c.strokeStyle = "#8b90a0";
              c.lineWidth = width;
            }
            c.stroke();
            if (!item.ionic) {
              c.beginPath();
              c.moveTo(A.x + ox - nx * width * 0.18, A.y + oy - ny * width * 0.18);
              c.lineTo(B.x + ox - nx * width * 0.18, B.y + oy - ny * width * 0.18);
              c.strokeStyle = "rgba(255,255,255,0.35)";
              c.lineWidth = Math.max(1, width * 0.28);
              c.stroke();
            }
          }
          c.setLineDash([]);
        } else {
          const el = atoms[item.i].el;
          const base = baseColor(el);
          const r = Math.max(3, item.r);
          const g = c.createRadialGradient(item.x - r * 0.35, item.y - r * 0.38, r * 0.1, item.x, item.y, r);
          g.addColorStop(0, mix(base, [255, 255, 255], 0.62));
          g.addColorStop(0.45, mix(base, [255, 255, 255], 0));
          g.addColorStop(1, mix(base, [0, 0, 0], 0.5));
          c.beginPath();
          c.arc(item.x, item.y, r, 0, Math.PI * 2);
          c.fillStyle = g;
          c.fill();
          if (sel === item.i) {
            c.beginPath();
            c.arc(item.x, item.y, r + 5, 0, Math.PI * 2);
            c.strokeStyle = "#7ef0c0";
            c.lineWidth = 2.5;
            c.stroke();
          }
          if (lab && r > 9) {
            c.fillStyle = el === "H" ? "#222" : "#fff";
            c.font = `600 ${Math.min(16, Math.max(10, r * 0.8))}px system-ui, sans-serif`;
            c.textAlign = "center";
            c.textBaseline = "middle";
            c.fillText(el, item.x, item.y + 0.5);
          }
          hits.push({ i: item.i, x: item.x, y: item.y, r: Math.max(r, 14), z: item.z });
        }
      }
      drawn.current = hits;
    };

    raf = requestAnimationFrame(frame);

    // ---- interactions ----
    const pointers = new Map<number, { x: number; y: number }>();
    let moved = 0;
    let pinch = 0;

    const down = (e: PointerEvent) => {
      canvas.setPointerCapture(e.pointerId);
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      view.current.dragging = true;
      view.current.idle = 0;
      moved = 0;
      if (pointers.size === 2) {
        const [p, q] = [...pointers.values()];
        pinch = Math.hypot(p.x - q.x, p.y - q.y);
      }
    };
    const move = (e: PointerEvent) => {
      const prev = pointers.get(e.pointerId);
      if (!prev) return;
      const cur = { x: e.clientX, y: e.clientY };
      pointers.set(e.pointerId, cur);
      view.current.idle = 0;
      if (pointers.size === 2) {
        const [p, q] = [...pointers.values()];
        const d = Math.hypot(p.x - q.x, p.y - q.y);
        if (pinch > 0) view.current.zoom = Math.min(3, Math.max(0.5, view.current.zoom * (d / pinch)));
        pinch = d;
        moved += 10;
      } else {
        const dx = cur.x - prev.x, dy = cur.y - prev.y;
        moved += Math.abs(dx) + Math.abs(dy);
        view.current.yaw += dx * 0.01;
        view.current.pitch = Math.max(-1.4, Math.min(1.4, view.current.pitch + dy * 0.01));
      }
    };
    const up = (e: PointerEvent) => {
      if (!pointers.has(e.pointerId)) return;
      pointers.delete(e.pointerId);
      if (pointers.size === 0) {
        view.current.dragging = false;
        if (moved < 6) {
          const rect = canvas.getBoundingClientRect();
          const x = e.clientX - rect.left, y = e.clientY - rect.top;
          let best: { i: number; z: number } | null = null;
          for (const hit of drawn.current) {
            if (Math.hypot(hit.x - x, hit.y - y) <= hit.r && (!best || hit.z > best.z)) best = { i: hit.i, z: hit.z };
          }
          live.current.onSelect(best ? best.i : null);
        }
      }
      pinch = 0;
    };
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      view.current.idle = 0;
      view.current.zoom = Math.min(3, Math.max(0.5, view.current.zoom * (e.deltaY > 0 ? 0.92 : 1.08)));
    };

    canvas.addEventListener("pointerdown", down);
    canvas.addEventListener("pointermove", move);
    canvas.addEventListener("pointerup", up);
    canvas.addEventListener("pointercancel", up);
    canvas.addEventListener("wheel", wheel, { passive: false });
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      canvas.removeEventListener("pointerdown", down);
      canvas.removeEventListener("pointermove", move);
      canvas.removeEventListener("pointerup", up);
      canvas.removeEventListener("pointercancel", up);
      canvas.removeEventListener("wheel", wheel);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="mol-canvas"
      style={{ height }}
      role="img"
      aria-label={`Modèle 3D de ${molecule.name}. Glisse pour tourner, pince pour zoomer.`}
    />
  );
}
