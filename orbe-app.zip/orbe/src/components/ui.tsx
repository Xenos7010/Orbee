import { useEffect, useState, type ReactNode } from "react";
import type { ScoreLetter } from "../lib/types";
import { IconClose } from "./icons";

/** 2 → ₂ ; gère aussi les charges des ions. */
const SUB = "₀₁₂₃₄₅₆₇₈₉";
const CHARGED: Record<string, string> = {
  "HCO3−": "HCO₃⁻",
  "SO42−": "SO₄²⁻",
  "[Ca(H2O)6]2+": "[Ca(H₂O)₆]²⁺",
  "[Mg(H2O)6]2+": "[Mg(H₂O)₆]²⁺",
  "[Na(H2O)4]+": "[Na(H₂O)₄]⁺",
  "[K(H2O)4]+": "[K(H₂O)₄]⁺",
  "[Cl(H2O)4]−": "[Cl(H₂O)₄]⁻",
};

export function prettyFormula(f: string): string {
  if (CHARGED[f]) return CHARGED[f];
  return f.replace(/\d/g, (d) => SUB[Number(d)]);
}

/** Image produit avec repli sur l'initiale si elle ne charge pas (hors ligne, lien cassé). */
export function SafeImg({ src, alt, letter }: { src: string | null; alt: string; letter: string }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [src]);
  if (!src || failed) return <b>{letter.slice(0, 1)}</b>;
  return <img src={src} alt={alt} loading="lazy" onError={() => setFailed(true)} />;
}

export function Sheet({ title, onClose, children }: { title?: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);
  return (
    <div className="sheet-wrap" role="dialog" aria-modal="true" aria-label={title}>
      <button className="sheet-backdrop" aria-label="Fermer" onClick={onClose} />
      <div className="sheet">
        <div className="sheet-grip" />
        <button className="icon-btn sheet-close" onClick={onClose} aria-label="Fermer">
          <IconClose />
        </button>
        <div className="sheet-body">{children}</div>
      </div>
    </div>
  );
}

export function Seg<T extends string>({
  value,
  onChange,
  options,
  label,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string }[];
  label: string;
}) {
  return (
    <div className="seg" role="tablist" aria-label={label}>
      {options.map((o) => (
        <button
          key={o.value}
          role="tab"
          aria-selected={o.value === value}
          className={o.value === value ? "on" : ""}
          onClick={() => onChange(o.value)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Toggle({ on, onChange, children }: { on: boolean; onChange: (v: boolean) => void; children: ReactNode }) {
  return (
    <button className={`toggle ${on ? "on" : ""}`} role="switch" aria-checked={on} onClick={() => onChange(!on)}>
      <span className="toggle-dot" />
      {children}
    </button>
  );
}

export function ScoreBadge({ letter, kind = "nutri", size = "md" }: { letter: ScoreLetter | number | null; kind?: "nutri" | "nova" | "eco"; size?: "sm" | "md" | "lg" }) {
  if (letter == null) return <span className={`score score-${size} score-none`}>?</span>;
  const key = String(letter).toLowerCase();
  const text = kind === "nova" ? key : key.toUpperCase();
  return <span className={`score score-${size} ${kind === "nova" ? `nova-${key}` : `s-${key}`}`}>{text}</span>;
}

export function Empty({ title, text, action }: { title: string; text: string; action?: ReactNode }) {
  return (
    <div className="empty">
      <h2>{title}</h2>
      <p>{text}</p>
      {action}
    </div>
  );
}

export function Spinner({ label }: { label: string }) {
  return (
    <div className="spinner-wrap" role="status">
      <span className="spinner" />
      <span>{label}</span>
    </div>
  );
}

export function SectionTitle({ eyebrow, children }: { eyebrow?: string; children: ReactNode }) {
  return (
    <div className="section-title">
      {eyebrow && <span className="eyebrow">{eyebrow}</span>}
      <h2>{children}</h2>
    </div>
  );
}
