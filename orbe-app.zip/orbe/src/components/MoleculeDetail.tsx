import { useEffect, useMemo, useState } from "react";
import { ELEMENTS, getMolecule, type El, type Molecule } from "../lib/molecules";
import { ELEMENT_BY_SYMBOL } from "../data/elements";
import { MoleculeViewer } from "./MoleculeViewer";
import { Toggle, prettyFormula } from "./ui";
import { href } from "../router";

const ORDER: El[] = ["C", "H", "O", "N", "P", "S", "Na", "K", "Ca", "Mg", "Cl", "Si"];

export function elementChips(m: Molecule) {
  return ORDER.filter((el) => m.counts[el]).map((el) => ({ el, n: m.counts[el] as number }));
}

/** Petit aperçu statique d'une molécule (pour les cartes de la bibliothèque). */
export function MiniMolecule({ molecule, size = 72 }: { molecule: Molecule; size?: number }) {
  const shape = useMemo(() => {
    const yaw = 0.7, pitch = -0.4;
    const big = molecule.atoms.length > 28;
    const keep = molecule.atoms.map((a) => !(big && a.el === "H"));
    let cx = 0, cy = 0, cz = 0;
    for (const a of molecule.atoms) { cx += a.p[0]; cy += a.p[1]; cz += a.p[2]; }
    cx /= molecule.atoms.length; cy /= molecule.atoms.length; cz /= molecule.atoms.length;
    const pts = molecule.atoms.map((a) => {
      const x = a.p[0] - cx, y = a.p[1] - cy, z = a.p[2] - cz;
      const x1 = x * Math.cos(yaw) + z * Math.sin(yaw);
      const z1 = -x * Math.sin(yaw) + z * Math.cos(yaw);
      return { x: x1, y: -(y * Math.cos(pitch) - z1 * Math.sin(pitch)), z: y * Math.sin(pitch) + z1 * Math.cos(pitch) };
    });
    let R = 0.5;
    pts.forEach((p, i) => { if (keep[i]) R = Math.max(R, Math.hypot(p.x, p.y) + 0.5); });
    const k = (size / 2 - 3) / R;
    return { pts, keep, k };
  }, [molecule, size]);
  const c = size / 2;
  const order = molecule.atoms.map((_, i) => i).filter((i) => shape.keep[i]).sort((a, b) => shape.pts[a].z - shape.pts[b].z);
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} aria-hidden="true">
      {molecule.bonds.map((b, i) =>
        shape.keep[b.a] && shape.keep[b.b] ? (
          <line key={i} x1={c + shape.pts[b.a].x * shape.k} y1={c + shape.pts[b.a].y * shape.k} x2={c + shape.pts[b.b].x * shape.k} y2={c + shape.pts[b.b].y * shape.k} stroke="#6b7184" strokeWidth={Math.max(1.2, shape.k * 0.12)} strokeLinecap="round" />
        ) : null,
      )}
      {order.map((i) => {
        const a = molecule.atoms[i];
        const col = ELEMENTS[a.el].color;
        return <circle key={i} cx={c + shape.pts[i].x * shape.k} cy={c + shape.pts[i].y * shape.k} r={Math.max(2, ELEMENTS[a.el].radius * shape.k)} fill={a.el === "C" ? "#5b5f6b" : col} stroke="rgba(0,0,0,.35)" strokeWidth=".6" />;
      })}
    </svg>
  );
}

export function MoleculeDetail({ moleculeId, intro }: { moleculeId: string; intro?: string }) {
  const molecule = getMolecule(moleculeId);
  const [volume, setVolume] = useState(false);
  const [showH, setShowH] = useState(true);
  const [labels, setLabels] = useState(true);
  const [atom, setAtom] = useState<number | null>(null);

  useEffect(() => setAtom(null), [moleculeId]);

  const chips = elementChips(molecule);
  const picked = atom != null ? molecule.atoms[atom] : null;
  const info = picked ? ELEMENTS[picked.el] : null;
  const big = molecule.atoms.length > 40;

  return (
    <div className="mol-detail">
      <div className="mol-stage">
        <MoleculeViewer molecule={molecule} showH={showH} volume={volume} labels={labels} selected={atom} onSelect={setAtom} height={300} />
        <span className="mol-hint">Glisse pour tourner · pince pour zoomer · touche un atome</span>
      </div>

      <div className="toggles">
        <Toggle on={!volume} onChange={(v) => setVolume(!v)}>Billes et bâtons</Toggle>
        <Toggle on={showH} onChange={setShowH}>Hydrogènes</Toggle>
        <Toggle on={labels} onChange={setLabels}>Noms</Toggle>
      </div>

      {picked && info ? (
        <a className="atom-card" href={href(`/tableau/${picked.el}`)}>
          <span className="atom-dot" style={{ background: picked.el === "C" ? "#5b5f6b" : info.color }}>{picked.el}</span>
          <span>
            <strong>{info.name}</strong>
            <small>{info.role}</small>
          </span>
          <span className="atom-go">Tableau ›</span>
        </a>
      ) : (
        <p className="muted small">Touche un atome pour savoir de quel élément il s'agit.</p>
      )}

      <div className="mol-title">
        <h3>{molecule.name}</h3>
        <span className="formula">{prettyFormula(molecule.formula)}</span>
      </div>
      <p className="lead">{intro ?? molecule.blurb}</p>
      {intro && <p className="muted">{molecule.blurb}</p>}

      <dl className="facts">
        <div><dt>Famille</dt><dd>{molecule.family}</dd></div>
        <div><dt>Atomes</dt><dd>{molecule.atoms.length}</dd></div>
        <div><dt>Masse molaire</dt><dd>{molecule.mass.toLocaleString("fr-FR")} g/mol</dd></div>
      </dl>

      <h4 className="sub">Éléments qui la composent</h4>
      <div className="chips wrap">
        {chips.map(({ el, n }) => (
          <a key={el} className="chip" href={href(`/tableau/${el}`)}>
            <span className="dot" style={{ background: el === "C" ? "#5b5f6b" : ELEMENTS[el].color }} />
            {ELEMENT_BY_SYMBOL[el]?.name ?? el} <b>×{n}</b>
          </a>
        ))}
      </div>

      {molecule.schematic && (
        <p className="note">
          Modèle simplifié : la forme montrée représente la famille de la molécule, pas sa structure exacte.
        </p>
      )}
      {big && <p className="muted small">Grosse molécule : pense à masquer les hydrogènes pour mieux voir le squelette.</p>}
    </div>
  );
}
