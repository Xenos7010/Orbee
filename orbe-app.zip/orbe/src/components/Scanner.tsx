import { useEffect, useRef, useState, type FormEvent } from "react";
import { IconClose } from "./icons";

/** Scanner plein écran. Utilise la caméra arrière et ne lit que les codes-barres alimentaires (EAN/UPC). */
export function Scanner({ onCode, onClose }: { onCode: (code: string) => void; onClose: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [manual, setManual] = useState("");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let stop: (() => void) | null = null;
    let dead = false;
    (async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error("no-camera");
        const [{ BrowserMultiFormatReader }, { DecodeHintType, BarcodeFormat }] = await Promise.all([
          import("@zxing/browser"),
          import("@zxing/library"),
        ]);
        const hints = new Map();
        hints.set(DecodeHintType.POSSIBLE_FORMATS, [BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A, BarcodeFormat.UPC_E]);
        hints.set(DecodeHintType.TRY_HARDER, true);
        const reader = new BrowserMultiFormatReader(hints, { delayBetweenScanAttempts: 100 });
        const controls = await reader.decodeFromConstraints(
          { video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } } },
          videoRef.current!,
          (result) => {
            if (!result || dead) return;
            const text = result.getText().replace(/\D/g, "");
            if (!/^\d{8,14}$/.test(text)) return;
            dead = true;
            controls.stop();
            navigator.vibrate?.(40);
            onCode(text);
          },
        );
        if (dead) controls.stop();
        stop = () => controls.stop();
        setReady(true);
      } catch {
        setError("Impossible d'activer la caméra. Autorise-la dans les réglages, ou saisis le code à la main ci-dessous.");
      }
    })();
    return () => {
      dead = true;
      stop?.();
    };
  }, [onCode]);

  function submit(e: FormEvent) {
    e.preventDefault();
    const digits = manual.replace(/\D/g, "");
    if (/^\d{8,14}$/.test(digits)) onCode(digits);
    else setError("Un code-barres compte entre 8 et 14 chiffres.");
  }

  return (
    <div className="scanner" role="dialog" aria-modal="true" aria-label="Scanner un code-barres">
      <video ref={videoRef} muted playsInline autoPlay className="scanner-video" />
      <div className="scanner-shade" />
      <button className="icon-btn scanner-close" onClick={onClose} aria-label="Fermer le scanner"><IconClose /></button>
      <div className="scanner-frame" aria-hidden="true">
        <span /><span /><span /><span />
        {ready && <i className="scanner-line" />}
      </div>
      <div className="scanner-panel">
        <p className="scanner-msg">{error ?? (ready ? "Place le code-barres dans le cadre" : "Ouverture de la caméra…")}</p>
        <form onSubmit={submit} className="scanner-form">
          <input value={manual} onChange={(e) => setManual(e.target.value)} inputMode="numeric" placeholder="Ou tape le code-barres" aria-label="Code-barres" />
          <button className="btn primary" type="submit">Ouvrir</button>
        </form>
      </div>
    </div>
  );
}
