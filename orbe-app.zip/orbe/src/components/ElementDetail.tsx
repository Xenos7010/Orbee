import { CATEGORIES, ELEMENTS_LIST, STATE_LABEL, type ChemElement } from "../data/elements";
import { MOLECULES, LIBRARY_ORDER, type El } from "../lib/molecules";
import { go, href } from "../router";
import { IconBack, IconChevron } from "./icons";
import { prettyFormula } from "./ui";

function Shells({ el }: { el: ChemElement }) {
  const color = CATEGORIES[el.category].color;
  const n = el.shells.length;
  const step = n > 1 ? Math.min(14, 82 / (n - 1)) : 0;
  const half = 30 + (n - 1) * step + 12;
  return (
    <svg className="shells" viewBox={`${110 - half} ${110 - half} ${half * 2} ${half * 2}`} role="img" aria-label={`Couches électroniques : ${el.shells.join(", ")}`}>
      {el.shells.map((count, i) => {
        const r = 30 + i * step;
        const dur = 14 + i * 5;
        return (
          <g key={i}>
            <circle cx="110" cy="110" r={r} fill="none" stroke="rgba(255,255,255,.14)" strokeWidth="1" />
            <g className="orbit" style={{ animationDuration: `${dur}s`, animationDirection: i % 2 ? "reverse" : "normal" }}>
              {Array.from({ length: count }, (_, k) => {
                const a = (k / count) * Math.PI * 2 + i;
                return <circle key={k} cx={110 + r * Math.cos(a)} cy={110 + r * Math.sin(a)} r={count > 18 ? 2.1 : 2.8} fill={color} />;
              })}
            </g>
          </g>
        );
      })}
      <circle cx="110" cy="110" r="17" fill={color} opacity=".9" />
      <text x="110" y="115" textAnchor="middle" fontSize="14" fontWeight="700" fill="#0a0b10">{el.sym}</text>
    </svg>
  );
}

export function ElementDetail({ el }: { el: ChemElement }) {
  const cat = CATEGORIES[el.category];
  const prev = ELEMENTS_LIST[el.z - 2];
  const next = ELEMENTS_LIST[el.z];
  const mols = LIBRARY_ORDER.map((id) => MOLECULES[id]).filter((m) => m && m.counts[el.sym as El]);
  const outer = el.shells[el.shells.length - 1];

  return (
    <div className="el-detail">
      <div className="el-nav">
        {prev ? (
          <button className="chip" onClick={() => go(`/tableau/${prev.sym}`)}><IconBack /> {prev.sym}</button>
        ) : <span />}
        {next ? (
          <button className="chip" onClick={() => go(`/tableau/${next.sym}`)}>{next.sym} <IconChevron /></button>
        ) : <span />}
      </div>

      <div className="el-head">
        <div className="el-tile" style={{ borderColor: cat.color, color: cat.color, boxShadow: `0 0 40px -12px ${cat.color}` }}>
          <small>{el.z}</small>
          <b>{el.sym}</b>
          <span>{el.mass.toLocaleString("fr-FR")}</span>
        </div>
        <div>
          <h3>{el.name}</h3>
          <span className="cat-pill" style={{ color: cat.color, borderColor: cat.color }}>{cat.short}</span>
        </div>
      </div>

      <p className="lead">{el.use}</p>
      {el.food && (
        <p className="food">
          <b>Dans l'assiette</b>
          {el.food}
        </p>
      )}

      <dl className="facts">
        <div><dt>Numéro atomique</dt><dd>{el.z}</dd></div>
        <div><dt>{el.massApprox ? "Nombre de masse" : "Masse atomique"}</dt><dd>{el.mass.toLocaleString("fr-FR")}</dd></div>
        <div><dt>À 20 °C</dt><dd>{STATE_LABEL[el.state]}</dd></div>
        <div><dt>Couche externe</dt><dd>{outer} électron{outer > 1 ? "s" : ""}</dd></div>
      </dl>

      <h4 className="sub">Ses électrons</h4>
      <div className="shells-wrap">
        <Shells el={el} />
        <p className="muted small">
          Chaque cercle est une couche. Répartition : <b>{el.shells.join(" · ")}</b>.
        </p>
      </div>

      <h4 className="sub">Famille</h4>
      <p className="muted">{cat.hint}</p>

      {mols.length > 0 && (
        <>
          <h4 className="sub">Molécules qui en contiennent</h4>
          <div className="chips wrap">
            {mols.map((m) => (
              <a key={m.id} className="chip" href={href(`/molecules/${m.id}`)}>
                {m.name} <span className="muted">{prettyFormula(m.formula)}</span>
              </a>
            ))}
          </div>
        </>
      )}
      <p className="muted small tiny">Éléments radioactifs sans isotope stable : la valeur indiquée est le nombre de masse de l'isotope le plus stable.</p>
    </div>
  );
}

