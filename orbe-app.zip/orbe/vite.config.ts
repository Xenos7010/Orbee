import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// base "./" : indispensable pour que l'appli fonctionne dans l'APK (fichiers locaux).
export default defineConfig({
  base: "./",
  plugins: [react()],
  build: { target: "es2020", chunkSizeWarningLimit: 900 },
});
