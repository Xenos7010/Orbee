import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.orbe.app",
  appName: "ORBE",
  webDir: "dist",
  backgroundColor: "#07080c",
  android: { backgroundColor: "#07080c" },
};

export default config;
